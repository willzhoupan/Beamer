import os, sys
import os.path
import glob
import subprocess
import shlex
import logging
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
from scipy.optimize import least_squares

DATEFMT ="[%Y-%m-%d %H:%M:%S]"
FORMAT = "%(asctime)s - %(name)s - %(message)s"
logging.basicConfig(level=logging.DEBUG,format=FORMAT,datefmt=DATEFMT,filename='scheduler.log')

logger = logging.getLogger('mlflowscheduler.readinfo')


def func0(x,a,b,c):
    return a*np.exp(-b*x)+c

def func1(x,a,b,c):
    return c-1/(a*x+b)

def func2(x,a,b,c,d):
    #return a*x**b+c
    return c-1/(a*x**d+b)

def func3(x,a,b,c,d):
    return 1/(a*x*x+b*x+c)+d

def func4(x,a,b,c):
     return a*x**b+c

def lsqerror(p,x,y):
    a,b,c = p
    return func1(x,a,b,c) - y

def plotloss(filepath):
    joblist = []
    jobinfo = {}
    source = os.getcwd()
    filepath = source +"/" + filepath
    filenames = glob.glob(filepath+"/worker*.csv")
    if len(filenames) == 0:
       print('[plotloss] No worker training information')
       return
    for filename in filenames:
        workeraddr = ''
        iternumber = []
        acc = []
        invert_acc = []
        validation = []
        timeline = []
        totaltime = 0
        try:
            infile = open(filename,'r')
            while True:
                  line = infile.readline()
                  if line == '':
                     break
                  linearray = line.split(',')
                  print(linearray)
                  if len(linearray) < 4:
                     break
                  if linearray[0]=='IP:Port':
                     continue
                  else:
                     workeraddr = linearray[0]
                     iternumber.append(int(linearray[1]))
                     acc.append(float(linearray[2]))
                     invert_acc.append(1-float(linearray[2]))
                     if linearray[3] == 'None':
                        validation.append(None)
                     else:
                        #validation.append(float(linearray[3]))
                        pass

                     timeline.append(totaltime + float(linearray[4])/60)
                     totaltime = totaltime + float(linearray[4])/60     
            infile.close() 
        except Exception as e:
            logger.info(' [1] failed to read file:{0}; The error is: {1}'.format(filename, repr(e)))
        
       
        plt.figure(1)
        
        xtime = np.arange(0,len(acc),1)
        timenow = 1000
        xl = np.arange(0,20000,1)
        #xl = xtime
        '''
        coeff = np.polyfit(xtime[:2000],acc[:2000],3)
        yvals = np.polyval(coeff,xtime)
        '''
        ydata = np.array(acc[:])
        popt, pcov = curve_fit(func0,xtime[:timenow],acc[:timenow])
        a = popt[0]
        b = popt[1]
        c = popt[2]
        print("func0 coefficeincy: ")
        print(popt)
        yvals0 = func0(xl,a,b,c)
        

        popt, pcov = curve_fit(func4,xtime[:timenow],acc[:timenow])
        a = popt[0]
        b = popt[1]
        c = popt[2]
        print("func0 coefficeincy: ")
        print(popt)
        yvals4 = func4(xl,a,b,c)

        popt, pcov = curve_fit(func1,xtime[:timenow],acc[:timenow],p0=[0,1,1])
        a = popt[0]
        b = popt[1]
        c = popt[2]
        print("func1 coefficeincy: ")
        print(popt)
        yvals1 = func1(xl,a,b,c)
        

        popt, pcov = curve_fit(func2,xtime[:timenow],ydata[:timenow],p0=[0,1,1,0.5])
        a = popt[0]
        b = popt[1]
        c = popt[2]
        d = popt[3]
        print("func2 coefficeincy: ")
        print(popt)

        yvals2 = func2(xl,a,b,c,d)


        '''
        p0 = [0,1,1]
        popt = least_squares(lsqerror,p0,loss='cauchy',f_scale=0.1,args=(xtime[:timenow],ydata[:timenow]))
        print(popt.x)
        a = popt.x[0]
        b = popt.x[1]
        c = popt.x[2]
        yvals3 = func1(xl,a,b,c)
        '''
        plt.plot(xl[:],yvals0[:],'-r')
        plt.plot(xl[:],yvals1[:],'-k')
        plt.plot(xl[:],yvals2[:],'-g')
        plt.plot(xl[:],yvals4[:],'--k')

        plt.plot(xtime[:],ydata[:],'-b')
        plt.show()

    return   

if __name__ == "__main__":

    plotloss('data/')   

  

