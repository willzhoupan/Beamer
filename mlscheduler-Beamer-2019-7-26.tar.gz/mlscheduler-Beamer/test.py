import matplotlib.pyplot as plt
import 

    

if __name__ == "__main__":

     a = [1,2,None,4,5]
     b = [1,2,3,4,5]
     plt.plot(b,a,'-*')
     plt.show()
