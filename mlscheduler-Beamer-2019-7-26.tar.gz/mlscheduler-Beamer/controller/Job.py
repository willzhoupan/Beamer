import numpy as np
import copy
from Beamer import Beamer
import time
import os
class Job(object):
      def __init__(self,hNum,**kwarg):
          self.hostNum = hNum
          self.prio = 0 #init the priority of the job
          self.workerList = []
          self.serverList = []
          self.stageList = []
          self.weightList = []#used for beamer algorithm
          self.tailStage = 0#used for beamer algorithm
          self.stageCtimes = []
          self.stageNow = 0
          self.iterNow = 0.0
          # gradient computing
          self.gaptime = 0.0
          self.flowsEmpty = np.zeros((hNum,hNum),dtype=float)
          self.flowsNow = np.zeros((hNum,hNum),dtype=float)
          self.flowSize = 0.0
          #kwarg = {'jobID':1,'modelName':'DenseNet','modelSize':'576-MB','workerHosts':'0-1-2',
          #         'serverHosts':'3-4','stageSizes':'200-200-400','ctime':2,'weight':1.0,'maxStage':3,'iterStep':current_step}
          for k,v in kwarg.items():
              setattr(self,k,v)

          self.workers = self.workerAddrs.split('-')
          self.servers = self.serverAddrs.split('-')
          stages = self.stageSizes.split('-')
          for item in stages:
              self.stageList.append(float(item))
          self.stageGlobalPrio = np.zeros(len(stages),dtype=int)
          self.iterNow = float(self.iterStep)
          

      def init(self,hostIP_list):
          #try:   
              
              for item in self.workers:
                  workerIP, workerPort = item.split(':')
                  indx = hostIP_list.index(workerIP)
                  self.workerList.append(indx)
              self.workerList.sort(key=lambda k:k,reverse = False)
              print('JobID: '+ str(self.jobID))

              
              for item in self.servers:
                  serverIP, serverPort = item.split(':')
                  indx = hostIP_list.index(serverIP)
                  self.serverList.append(indx)
              self.serverList.sort(key=lambda k:k,reverse = False)
              
              #Init all stage_weight equals to self.weight
              for i in range(0,len(self.stageList)):
                  temp = 0.0
                  #computing w_jk
                  for j in range(i,len(self.stageList)):
                      temp += 1/self.stageList[j]
                  temp = temp*self.weight 
                  self.weightList.append(temp)
              
              self.tailStage = len(self.stageList) - 1
              fsize,funit = self.modelSize.split('-')
              self.flowSize = float(fsize)/float(len(self.serverList)) 
              self.UpdateState()
              print('=> serverlist: '+ str(self.serverList))
              print('=> iterNow: '+ str(self.iterNow))
              print('=> stageNow: '+ str(self.stageNow))  
          #except Exception as e:
          #       print(str(e))

      #update stageNow
      def UpdateState(self):
          if self.stageNow < 0:
                return 'completed!'          
          stage = -1
          #Check job stage
          for i in range(0,len(self.stageList)):
              if self.iterNow < self.stageList[i]:
                 stage = i
                 break
          if stage < 0 or stage > (self.maxStage-1): #job completed
             self.stageNow = -1
             #self.stageCtimes.append(timeNow)
             return 'completed!'
          else:
             stageOld = self.stageNow
             self.stageNow = stage
             self.prio = self.stageGlobalPrio[self.stageNow]
             print('=>stageGlobalPrio:'+str(self.stageGlobalPrio))
             if stageOld < stage:
                #self.stageCtimes.append(timeNow)
                return 'stage_change!' 
             return 'updated!'
            
                          
'''
if __name__ == "__main__":
      print('--------BeamerOnline started----------')
      t_start = time.time()
      notArrivingJobList = []
      successfulJobList = []
      schedulelist = []
      dcn = excutor()
      scheduler = Beamer()
      
      for item in config.notArrivingJobs:
          item[0] = item[0]/timeUnit
          #item[0] = 0
          if item[0] == 0:
             schedulelist.append(Job(hostNum,item[0],**item[1]))
          elif item[0] > 0:
             notArrivingJobList.append(item)
      notArrivingJobList.sort(key=lambda k:k[0],reverse = False)

      scheduler.GenerateStagePrio(schedulelist,dcn)

      #stage changed flag
      stageChageFlag = False
      #on-line schedule
      for timeNow in range(0,100000000):
          #delete finished jobs from schedulelist
          runningJobNum = len(schedulelist)
          notArrivingJobNum = len(notArrivingJobList)
          if runningJobNum == 0 and notArrivingJobNum == 0:
             print('All job have completed!')
             break
          
          tempList = []
          if notArrivingJobNum > 0:
             for k in range(0,notArrivingJobNum):
                 item = notArrivingJobList[k]
                 if item[0] > timeNow:
                    break
                 schedulelist.append(Job(hostNum,item[0],**item[1]))
                 tempList.append(item)
             for item in tempList:
                 notArrivingJobList.remove(item)
                 print('new job arrivals!')

          completedJobList = []
          #update states of all jobs
          for i in range(0,runningJobNum):
              job = schedulelist[i]
              state = job.UpdateState(timeNow)
              if state == 'completed!':
                 completedJobList.append(job)
                 stageChageFlag = True
                 print('a job completed')
                 continue
              elif state == 'stage_change!':
                 stageChageFlag = True
          #delete completed jobs from schedulelist
          for cjob in completedJobList:
              successfulJobList.append(cjob)
              schedulelist.remove(cjob)
          if stageChageFlag == True:
             stageChageFlag = False
             scheduler.GenerateStagePrio(schedulelist,dcn)
          dcn.TransferData(schedulelist)
      t_end = time.time()
      print('Total time is: '+ str(t_end-t_start))

      source = os.getcwd() + '/'
      filename = 'output-Beamer'
      fout = open(source + filename,'w')
      totalStages = 0.0
      ctimeSum = 0.0
      earlyStageTimeSum = 0.0
      firstStageTimeSum = 0.0
      jobCtimeSum = 0.0
      num50 = 0.0
      num90 = 0.0
      for job in successfulJobList:
          totalStages += len(job.stageCtimes)
          ctimeSum += sum(job.stageCtimes)*timeUnit
          if len(job.stageCtimes) >= 4:
             earlyStageTimeSum += job.stageCtimes[3]*timeUnit
             num90 += 1
          if len(job.stageCtimes) >= 3:
             firstStageTimeSum += job.stageCtimes[2]*timeUnit
             num50 += 1
          jobCtimeSum += job.stageCtimes[-1]*timeUnit
          #print('------------')
          #print(job.modelName)
          fout.write(job.modelName+','+str(job.JobId)+','+str((job.releaseTime)*timeUnit)+'\n')
          #print(job.stageCtimes)
          fout.write(str(job.stageCtimes))
          fout.write('\n')
      fout.close()
      print('Average stage time:')
      print(str(ctimeSum/totalStages)+' s')
      if num90 > 0:
         print('Early stage time(90%):')
         print(str(earlyStageTimeSum/num90)+ ' s')
      if num50 > 0:
         print('Early stage time(50%):')
         print(str(firstStageTimeSum/num50)+ ' s')
      print('Job completion time:')
      print(str(jobCtimeSum/len(successfulJobList))+ ' s')
'''



