#!/usr/bin/python
#coding:utf-8

import struct
import binascii
import ctypes
import json
import random
import socketserver
import socket
import fcntl
import threading 
import time
import os
import re
import logging
import copy
import readinfo
import tc
import iptables
import Job
import Beamer
import operator
#------------------------data structures------------------------------------------------------------------#
#@(1)  nodelist
#   |--------|----------|--------|------|--------|----------|--------|
#   |addr    | roles    |localID |jobID |agent   |heartbeats|priority|
#   |--------|----------|--------|------|--------|----------|--------|
#[0]|ip:port | worker   | xx     | xx   |ip:port |xx        | xx     |
#   |--------|----------|--------|------|--------|----------|--------|
#[1]|ip:port | server   | xx     | xx   |ip:port |xx        | xx     |
#   |--------|----------|--------|------|--------|----------|--------|
#[2]|ip:port | worker   | xx     | xx   |ip:port |xx        | xx     |
#   |--------|----------|--------|------|--------|----------|--------|
#
#@(2)  message type: agent_registor
#   dict{"msgtype":"agent_registor", "ip":"xx.xx.xx.xx","port":"xx"}
#
#@(3)  message type: job_registor
#   dict{"msgtype":"job_registor", "localID":"xx","node1":"worker:ip:port","node2":"ps:ip:port"...}
#
#@(4)  message type: heartbeat
#   dict{"msgtype":"heartbeat", "agentaddr":"ip:port","localID":"xx","workerAddr":"ip:port-ip:port","serverAddr":"ip:port-ip:port"...}
#
#
#@(5)  message type: scheduler_policy
#   dict{"msgtype":"scheduler_policy","tc_prio":"priority1:src_ip:src_port,priority2:src_ip:src_port..."
#        ,"dscp_prio":"priority1:dest_ip:dest_port,priority2:dest_ip:dest_port..."}
#   >> src_ip:src_port means the ip:port of the source 
#   >> dest_ip:dest_port means the ip:port of the destination
#------------------------------------------------------------------------------------------------------------#

msgid = 0 #message id for a new generated message
nodelist = [] #containing information of all nodes,such as workers, parameter servers and schedulers
job_classes_loc = threading.Lock()
job_classes = [] #((jobID,class pointer),(jobID,class pointer),...)
heartbeatcycle = 10 # xx seconds
schedulingcycle = 10 #xx seconds
policyupdatecycle = 5 # xx seconds
agentdic = {} #restored activing agents  {"ip:port":leftheartbeats,"ip:port":leftheartbeats,"ip:port":leftheartbeats...}
agent_left_heartbeats  = 10 # the agent will be delete from agentdic when agent_left_heartbeats is 0

agentdic_loc = threading.Lock() # agentdic, nodelistlocks

# store the received messages that wait for processing 
#messagelist = [{"messagehead": "headPack","messagebody": "msgdic"},{},{}...]
messagelist = [] 
messagelist_loc = threading.Lock()
messageevent = threading.Event() # if received a message, the event will be set

config_loc = threading.Lock()
infofilepath = '' #the path to read job or node information for agents
node_role = "controller"  #node_role = controller or agent
controllerip = '127.0.0.1'
controllerport = 8888
agentip = '127.0.0.1'
agentport = 8886
agent_host_password = '111111\n'
nicname = 'eno3'

DATEFMT ="[%Y-%m-%d %H:%M:%S]"
FORMAT = "%(asctime)s - %(name)s - %(message)s"
logging.basicConfig(level=logging.DEBUG,format=FORMAT,datefmt=DATEFMT,filename='scheduler.log')

logger = logging.getLogger('mlflowscheduler.'+node_role)
#=================================get local ip address==============================
def get_ip(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', bytes(ifname[:15],'utf-8')))[20:24])
#=================================controller threads================================
#------------Socket server thread-----------------------------
class Myserver(socketserver.BaseRequestHandler):
    
    def handle(self):
        conn = self.request
        conn.sendall(b'fuck connected')
        dataBuffer = bytes()
        headerSize = 20
        while True:
            data = conn.recv(1024)
            ret_str = str(data)
            if ret_str == "quick!":
               conn.sendall(b'fuck!! quick!')
               break
            if data: #received some data
               dataBuffer += data #store data into databuffer
            while True:
                  if len(dataBuffer) < headerSize:
                     #print("Packet header is not fully received,continue to receive...")
                     break
                  #read packet header
                  # struct:! is Network order, 12s is 12 unsigned chars, 2I is 2 unsigned int data
                  headPack = struct.unpack('!12s2I', dataBuffer[:headerSize])
                  if headPack[0] != b'messagestart':
                     dataBuffer = dataBuffer[1:]  #point to next bytes
                     print("find messagestart...")
                     break
                  bodySize = headPack[1]

                  if len(dataBuffer) < headerSize+bodySize : 
                     #print("Packet body is not fully received,continue to receive...")
                     break
                  #read message body
                  body = dataBuffer[headerSize:headerSize+bodySize]
                  # process received message 
                  self.dataHandle(headPack, body)
                  conn.sendall(b'fuck!! message is processed!')
                  # get next message
                  dataBuffer = dataBuffer[headerSize+bodySize:] 
         
    def dataHandle(self,headPack,body):
        msgjson = body.decode()
        msgdic=json.loads(msgjson)
        #print('[dataHandle] the received messaage dict address is: %s' % id(msgdic))
        if 'msgtype' in msgdic:
           if msgdic['msgtype'] == 'agent_registor':
              self.agentRegister(headPack,msgdic)
           elif msgdic['msgtype'] == 'job_registor':
              self.jobRegister(headPack,msgdic)
           elif msgdic['msgtype'] == 'heartbeat':
              self.heartBeatUpdate(headPack,msgdic)
           elif msgdic['msgtype'] == 'scheduler_policy':
              self.schedulerPolicyReceived(headPack,msgdic)
           else:
              print("No such message type, the message is: \n")
              print(msgdic+'\n')
        else:
           print("The message is not a pre-defined format")
           print("%s, bodySize:%s, cmd:%s\n" % headPack)
           print(msgdic)

    def agentRegister(self,headPack,msgdic):#store ip:port into agentdic
        print("agent register begin...")
        global agentdic, agent_left_heartbeats
        if 'agentaddr' in msgdic:
           agentdic_loc.acquire()
           agentdic[msgdic['agentaddr']] = agent_left_heartbeats#'ip:port':xx
           agentdic_loc.release()
        print("agents are listed:\n")
        print(agentdic)

    def jobRegister(self,headPack,msgdic):#store information of the job's nodes to nodelist
        print("job register begin...")
        agentdic_loc.acquire()
        if 'chiefAddr' in msgdic:
           chiefAddr = msgdic['chiefAddr']
        if 'localID' in msgdic:
           joblocalID = msgdic['localID']
        # generate jobID for different jobs
        global agentdic, nodelist
        existnodes = []
        if len(chiefAddr)>0 and len(joblocalID)>0:
           hashinput = chiefAddr + joblocalID
           jobID = hash(hashinput)
           # create or update job class
           job_classes_loc.acquire()
           global job_classes
           existJobClass = []
           for item in job_classes:
               if jobID == item.jobID:
                  existJobClass.append(item)
           #delete the old classes with same jobID
           for item in existJobClass: 
               indx = job_classes.index(item)
               job_classes.pop(indx)
           #create new job class for the jobID
           msgdic['jobID'] = jobID
           newjob = Job.Job(len(agentdic),**msgdic)
           job_classes.append(newjob)
           job_classes_loc.release()

           # store registor information in nodelist
           for key in msgdic:
               if key == 'msgtype':
                  pass
               elif key == 'scheduler':
                  pass  
               elif key == 'localID':
                  pass
               elif key == 'workerAddrs' or key == 'serverAddrs': #worker or ps
                  nodeAddrs = msgdic[key].split('-')
                  role,abandon_str = key.split('A')
                  for nodeAddr in nodeAddrs:
                      nodeip, nodeport = nodeAddr.split(':')
                      nodeaddr = nodeip+':'+nodeport
                      nodedic = {'addr':nodeaddr,'roles':role,'localID':joblocalID,
                             'jobID':jobID,'heartbeats':agent_left_heartbeats}
                      existnodes = []
                      for agentkey in agentdic:
                          agent_ip,agent_port = agentkey.split(':')
                          if agent_ip == nodeip:
                             nodedic['agentaddr'] = agentkey
                             #if the node is exist, delete it and insert the new information
                             for item in nodelist:
                                 if item['addr']==nodeaddr:
                                    existnodes.append(item)
                             for item in existnodes:
                                 indx = nodelist.index(item)
                                 nodelist.pop(indx)
                                 print(item)
                                 print("is exist, its index is %s and it is deleted" %indx)
                          
                             nodelist.append(nodedic)
                             print(nodedic)
                             break
               else:
                   pass
           print("job registor end")
           print("nodelist is :")
           print (nodelist)
        agentdic_loc.release()

# update the left heat beats for each agent and node
# if the node or agent is not exist, the node or agent will be registered
# if the node is exist, the node will be updated
    def heartBeatUpdate(self,headPack,msgdic):
        try:
            print("heartbeat process begin...")
            global agentdic, agent_left_heartbeats, nodelist
            # update left_heat_beats of agents
            if 'agentaddr' in msgdic:
               agentdic_loc.acquire()
               agentdic[msgdic['agentaddr']] = agent_left_heartbeats#reset the left-heartbeats
               agentdic_loc.release()
            print("heartbeats of agent %s is set to %s\n" % (msgdic['agentaddr'], agentdic[msgdic['agentaddr']]))

            # update left_heat_beats of nodes (workers and parameter servers)
            if len(msgdic) >=3:
               if 'chiefAddr' in msgdic:
                  chiefAddr = msgdic['chiefAddr']
               if 'localID' in msgdic:
                  joblocalID = msgdic['localID']
               # generate jobID for different jobs
               if len(chiefAddr)>0 and len(joblocalID)>0:
                  hashinput = chiefAddr + joblocalID
                  jobID = hash(hashinput)

               # create or update job class
               job_classes_loc.acquire()
               global job_classes
               existJobClass = []
               for item in job_classes:
                   if jobID == item.jobID:
                      existJobClass.append(item)
               #delete the old classes with same jobID
               for item in existJobClass: 
                   indx = job_classes.index(item)
                   job_classes.pop(indx)
               #create new job class for the jobID
               msgdic['jobID'] = jobID
               newjob = Job.Job(len(agentdic),**msgdic)
               job_classes.append(newjob)
               job_classes_loc.release()
               print('heartbeatUpate->msgdic: ')
               print(msgdic)

               # store registor information
               agentdic_loc.acquire()
               for key in msgdic:
                   if key == 'msgtype':
                      pass
                   elif key == 'scheduler':
                      pass  
                   elif key == 'localID':
                      pass
                   elif key == 'workerAddrs' or key == 'serverAddrs': #worker or ps
                      nodeAddrs = msgdic[key].split('-')
                      role,abandon_str = key.split('A')
                      for nodeAddr in nodeAddrs:
                          nodeip, nodeport = nodeAddr.split(':')
                          nodeaddr = nodeip+':'+nodeport
                          nodedic = {'addr':nodeaddr,'roles':role,'localID':joblocalID,
                                 'jobID':jobID,'heartbeats':agent_left_heartbeats}
                          existnodes = []
                          for agentkey in agentdic:
                              agent_ip,agent_port = agentkey.split(':')
                              if agent_ip == nodeip:
                                 nodedic['agentaddr'] = agentkey
                                 #if the node is exist, delete it and insert the new information
                                 for item in nodelist:
                                     if item['addr']==nodeaddr:
                                        existnodes.append(item)
                                 for item in existnodes:
                                     indx = nodelist.index(item)
                                     nodelist.pop(indx)
                                     print(item)
                                     print("is exist, its index is %s and it is deleted" %indx)
                          
                                 nodelist.append(nodedic)
                                 print(nodedic)
                                 break
                   else:
                       pass
               print("job registor end")
               print("nodelist is :")
               print (nodelist)
               logger.info(' [2] A heartbeat message has been processed; The nodelist is {0}'.format(str(nodelist)))
               agentdic_loc.release()

        except Exception as e:
               job_classes_loc.release()
               print(str(e))   

    def schedulerPolicyReceived(self,headPack,msgdic):
        messagedic = dict(messagehead = headPack,messagebody = msgdic)
        messagelist_loc.acquire()
        global messagelist
        msglistbuf = messagelist[:]
        #deleting the old policy messages for excuting new policy
        for msg in msglistbuf:
            msgbody = msg['messagebody']
            # if the msg is a policy message, deleting it
            if 'scheduler_policy' in msgbody: 
               indx = messagelist.index(msg)
               messagelist.pop(indx)            
        messagelist.append(messagedic)
        messagelist_loc.release()
        # tell the message processing thread that a message is received
        messageevent.set()

#-----------socket client precess-----------------------------
class SocketClientThread(threading.Thread):
      def __init__(self,server_ip_port,msglist):
          threading.Thread.__init__(self)
          self.serveraddr = server_ip_port  #"xx.xx.xx.xx:port"
          self.msgbuf = copy.deepcopy(msglist)

      def run(self):
          server_ip, port = self.serveraddr.split(':')
          server_port = int(port)         
          self.sk = socket.socket()
          try:
              self.sk.connect((server_ip,server_port))
          except socket.error as msg:
              self.sk.close()
              self.sk = None
              print("***socket client connect to "+self.serveraddr+" error: ")
              print(msg)
              
          if self.sk != None:
             ret_bytes = self.sk.recv(1024)
             ret_str = str(ret_bytes,encoding="utf-8")
             print(ret_str)
             for msg in self.msgbuf:
                 self.sendmessage(msg)
             time.sleep(1)
             ret_bytes = self.sk.recv(1024)
             ret_str = str(ret_bytes,encoding="utf-8")
             print(ret_str)
             self.sk.close()

      
      def sendmessage(self,msgbodydic):
          body = json.dumps(msgbodydic)
          print("***sending message is :")
          print(body)
          global msgid
          cmd = msgid
          header = [b'messagestart', body.__len__(), cmd]
          headPack = struct.pack("!12s2I", *header)
          sendData1 = headPack+body.encode()
          self.sk.sendall(sendData1)
          msgid += 1
#-----------Heartbeat thread----------------------------------
# decrease left_heart_beats for each agent and node
# if left_heart_beats is 0, the corresponding agent or node will be deleted
# note that: if the agent is deleted, the nodes attached to the agent are not be deleted,
#            if the controller select these nodes to predict job progress, there will be
#            agent to response.
class HeartBeatThread(threading.Thread):
    def __init__(self,arg):
        super(HeartBeatThread, self).__init__()#注意：一定要显式的调用父类的初始化函数。
        self.arg=arg
    def run(self):#定义每个线程要运行的函数
        global heartbeatcycle
        while True:
              time.sleep(heartbeatcycle)
              self.heartBeatProcess()

    def heartBeatProcess(self):
        global agentdic, agent_left_heartbeats, nodelist
        agentdic_loc.acquire()
        #minus the left_heartbeats for each agent
        delkeys = []
        for key  in agentdic.keys():
            #if left_heartbeats is 0, the agent is dead and will be deleted later
            if agentdic[key] <= 0:
               print('agent %s is deleted from system' %key)
               delkeys.append(key)
            else:
               agentdic[key] = agentdic[key]-1 
        for delkey in delkeys: #delete the dead agent
            del agentdic[delkey]
        print("agentdic after update:")
        print(agentdic) 

        #minus the left_heartbeats for each node
        delnodes = []
        for item  in nodelist:
            #if left_heartbeats is 0, the node is dead and will be deleted later
            if item['heartbeats'] <= 0:
               print('node %s is deleted from system' %item['addr'])
               delnodes.append(item)
            else:
               item['heartbeats'] = item['heartbeats']-1 
        for delnode in delnodes: #delete the dead node
            indx = nodelist.index(delnode)
            nodelist.pop(indx)
        print("nodelist after update:")
        print(nodelist)
        #delete dead jobs
        #step 1. find dead jobs
        job_classes_loc.acquire()
        dead_jobs = []
        for job in job_classes:
            isdead = True
            for node in nodelist:
                #if there exists a living node in the job
                if node['jobID'] == job.jobID:
                   isdead = False
                   break
            if isdead == True:
               dead_jobs.append(job)
        #step 2. delete dead jobs
        for job in dead_jobs:
            job_classes.remove(job)
        job_classes_loc.release()
        agentdic_loc.release()

#-----------Flow scheduler thread----------------------------------
class FlowShedulerThread(threading.Thread):
    def __init__(self,arg):
        super(FlowShedulerThread, self).__init__()
        self.arg=arg
    def run(self):
        selectedworkers = []
        #declare a scheduler
        scheduler = Beamer.Beamer()
        global schedulingcycle
        while True:
              time.sleep(schedulingcycle)
              print ('Flow scheduler is start:%s\n' % self.arg)
              try:
                  #generate hostIP_list
                  hostIP_list = []
                  agentdic_loc.acquire()
                  global agentdic
                  for key in agentdic.keys():
                      agent_ip, agent_port = key.split(':')
                      hostIP_list.append(agent_ip)
                  agentdic_loc.release()

                  job_classes_loc.acquire()
                  global job_classes
                  #init job variables, i.e., translate host_ip -> host_index
                  completed_jobs = []
                  for job in job_classes:
                      job.init(hostIP_list)
                      if job.stageNow < 0: 
                         completed_jobs.append(job)
                  #delete the completed jobs
                  for item in completed_jobs:
                      job_classes.remove(item)
                      
                  #generate stage orders
                  scheduler.GenerateStagePrio(job_classes,len(agentdic))
                  job_classes_loc.release()

              except Exception as e:
                     job_classes_loc.release()
                     print(str(e))
      
#-----------the thread is to Generate and send job priority to agents------------------
class PolicyUpdateThread(threading.Thread):
    def __init__(self,arg):
        super(PolicyUpdateThread, self).__init__()
        self.arg=arg
    def run(self):
        time.sleep(schedulingcycle)#wait for the first generated order by Beamer
        while True:
              time.sleep(policyupdatecycle)
              print ('Policy updating is start:%s\n' % self.arg)
              try:
                  #update job priorities
                  completed_jobs = []
                  job_classes_loc.acquire()
                  global job_classes
                  for job in job_classes:
                      job.UpdateState()
                      if job.stageNow < 0:
                         completed_jobs.append(job)
                  #delete the complted jobs
                  for item in completed_jobs:
                      job_classes.remove(item)
                  #generate job tc and dscp priorities
                  self.schedulingPolicyGenerate(job_classes)
                  job_classes_loc.release()
                  print ('Policy updating is successful')
              except Exception as e:
                     print(str(e))

    def schedulingPolicyGenerate(self, jc_list):


        # get the global variables
        agentdic_loc.acquire()
        global nodelist, agentdic
        nodelistbuf = copy.deepcopy(nodelist)
        agentdicbuf = copy.deepcopy(agentdic)
        agentdic_loc.release()
         
        #set priority to each nodes in the clusters, by following step 1,2
        #step 1. sort jobs according to job.prio
        cmpfun = operator.attrgetter('prio') 
        jc_list.sort(key=cmpfun,reverse = False)#sort jobs according to job.prio
        jobpriolist = []
        for i in range(0,len(jc_list)):
            item = jc_list[i]
            jobpriodic = dict(jobID=item.jobID,jobprio=i)
            jobpriolist.append(jobpriodic)
        print("***job prio sort is :")
        print(jobpriolist)          
        
        #step 2. set coressponding priority to each node with same jobID
        for item in jobpriolist:
            jobIDtemp = item['jobID']
            jobpriotemp = item['jobprio']
            for node in nodelistbuf:
                if node['jobID'] == jobIDtemp:
                   node['priority'] = jobpriotemp
        
        #generate local priority for each nodes in every agent       
        for agent in agentdicbuf.keys():
            node_in_agent = []
            nodepriodic = {}
            #find the nodes in the agent
            for node in nodelistbuf:
                agent_ip, agent_port = agent.split(':')
                nodeip, nodeport = node['addr'].split(':')
                if nodeip == agent_ip:
                   node_in_agent.append(node)
            if len(node_in_agent) == 0:
               continue
                
            #generate local priority
            node_in_agent.sort(key=lambda k: (k.get('priority', 0)))
            local_prio = 1
            last_node = {}
            for i in range(0,len(node_in_agent)):
                node = node_in_agent[i]
                if i > 0:
                     if node['priority'] != last_node['priority']:
                        local_prio = local_prio + 1
                node['localprio'] = local_prio
                last_node = node

        #generate the scheduling policy by using step1. and step2.
        policylist = []
        threadlist = []
        for agent in agentdicbuf.keys():
            node_in_agent = []
            nodepolicydic = {}
            #find the nodes in the agent
            for node in nodelistbuf:
                agent_ip, agent_port = agent.split(':')
                nodeip, nodeport = node['addr'].split(':')
                if nodeip == agent_ip:
                   node_in_agent.append(node)
            if len(node_in_agent) == 0:
               continue
  

            #set the input priority by using dscp value and output priority by linux tc
            tc_str = ''
            dscp_str = ''
            for agentnode in node_in_agent:
                if agentnode['roles'] == 'worker':
                   for node in nodelistbuf:
                       if node['jobID']==agentnode['jobID'] and node['roles']=='server':
                          #flows: worker->server input priority  dscp at server
                          dscp_str = dscp_str + str(node['localprio'])+':'+node['addr']+','
                          #flows: worker->server output priority tc at worker
                          tc_str = tc_str + str(agentnode['localprio'])+':'+node['addr']+',' 
                elif agentnode['roles'] == 'server':
                   for node in nodelistbuf:
                       if node['jobID']==agentnode['jobID'] and node['roles']=='worker':
                          #flows: server->worker input priority  dscp at worker
                          dscp_str = dscp_str + str(node['localprio'])+':'+node['addr']+',' 
                          #flows: server->worker output priority tc at server
                          tc_str = tc_str + str(agentnode['localprio'])+':'+node['addr']+','
            dscp_str = dscp_str[:-1]#delete the last char ',' 
            tc_str = tc_str[:-1]  #delete the last char ',' 
            nodepolicydic = dict(agentaddr=agent,tc_prio=tc_str,dscp_prio=dscp_str)
            policylist.append(nodepolicydic)
            #generate scheduler_policy message and send it
            agentaddr = agent
            msglist = []
            policymsg = nodepolicydic
            policymsg['msgtype'] = 'scheduler_policy'
            if len(policymsg) > 1:
               msglist.append(policymsg)
            newthread = SocketClientThread(agent,msglist)
            threadlist.append(newthread)
        for t in threadlist:
            t.setDaemon(True)
            t.start()
        print ("***%s policy sending threads start*****" %len(threadlist))

             
        return policylist

    def sendSchedulingPolicy(self, schedulingpolicy):
        msglist = []
        policymsg = {}
        policymsg = schedulingpolicy
        policymsg['msgtype'] = 'scheduler_policy'
        if len(policymsg) > 1:
           msglist.append(policymsg)

        agentdic_loc.acquire()
        global agentdic
        agentbuf = copy.deepcopy(agentdic)
        agentdic_loc.release()
                
        threadlist = []
        if len(msglist) >0 :
           for agentkey in agentbuf.keys():
               agentaddr = agentkey
               newthread = SocketClientThread(agentaddr,msglist)
               threadlist.append(newthread)
           for t in threadlist:
               t.setDaemon(True)
               t.start()

           print ("***%s policy sending threads start*****" %len(threadlist))
           time.sleep(1)         

#=================================Agent threads================================
#-----------agnet Heartbeat thread----------------------------------
class HeartBeatSending(threading.Thread):
    def __init__(self,arg):
        super(HeartBeatSending, self).__init__()
        self.arg=arg

    def run(self):
        while True:
              time.sleep(heartbeatcycle)
              self.sendheartbeatmsg()

    def sendheartbeatmsg(self):
        joblist = []
        jobinfolist = readinfo.readjobinfo(infofilepath)
        joblist = jobinfolist[:]
        for job in jobinfolist:
            if 'activetime' in job.keys():
               acttime = job['activetime']
               systime = time.time()
               timegap = systime - float(acttime)

               # distinguish the job is active or not
               #if timegap >= schedulingcycle:
               if timegap <= 0:
                  logger.info(' [1] a training job has been finished or killed; The scheduler ip:port is{0}'.format(job['chiefAddr']))
                  indx = joblist.index(job)
                  joblist.pop(indx)
               else:
                  indx = joblist.index(job)
                  del joblist[indx]['activetime']
        global agentip, agentport,controllerip,controllerport
        agent_ip_port = agentip+':'+str(agentport)
        #print("[Heartbeat] agent address is: %s\n" % agent_ip_port)  
        heartbeat_msglist = []                     
        for job in joblist:
            msgdic = copy.deepcopy(job)
            msgdic['msgtype'] = 'heartbeat'
            msgdic['agentaddr'] = agent_ip_port
            heartbeat_msglist.append(msgdic)
            msgdic = {}
        if len(joblist)==0:
           msgbodydic = dict(msgtype='heartbeat',agentaddr=agentip+':'+str(agentport))  
           heartbeat_msglist.append(msgbodydic)
        controlleraddr = controllerip+':'+str(controllerport)
        sendthread = SocketClientThread(controlleraddr,heartbeat_msglist)
        sendthread.start()
        sendthread.join()
        logger.info(' [0] Heartbeat messages are sent; The heartbeat messages are:{0}'.format(str(heartbeat_msglist)))

#-----------Agent Registed to controller thread------------------------------
class AgentRegistorThread(threading.Thread):
    def __init__(self,arg):
        super(AgentRegistorThread, self).__init__()
        self.arg=arg
    def run(self):

        time.sleep(1)
        global agentip, agentport
        msgbodydic = dict(msgtype='agent_registor',agentaddr=agentip+':'+str(agentport))
        agent_ip_port = agentip+':'+str(agentport)
        print ('Agent registor is started:%s\n' % agent_ip_port)
        registormsglist = []
        registormsglist.append(msgbodydic)
        controlleraddr = controllerip+':'+str(controllerport)
        sendthread = SocketClientThread(controlleraddr,registormsglist)
        sendthread.start()
        sendthread.join()

#-----------Request Event thread, the request is from controller-------------
class RequestEventThread(threading.Thread):
    def __init__(self,arg):
        super(RequestEventThread, self).__init__()
        self.arg=arg
    def run(self):
        time.sleep(1)
        print ('Request from:%s\n' % self.arg)


#-----------Message processing thread----------------------------------------
class MessageProcessThread(threading.Thread):
    def __init__(self):
        super(MessageProcessThread, self).__init__()
        
    def run(self):
        global messagelist
        msglist = []
        threadlist = []
        while True:
              messagelist_loc.acquire()
              msgnumber = len(messagelist)
              messagelist_loc.release()

              if msgnumber == 0:
                 print("***No messages in the messagelist, waiting for message arriving!")
                 messageevent.clear()
                 messageevent.wait()

              msglist = []# clear the buf
              messagelist_loc.acquire()
              msglist = messagelist[:]
              messagelist_loc.release()

              for msg in msglist:
                  msgbody = msg['messagebody']
                  msghead = msg['messagehead']
                  if msgbody['msgtype'] == 'utility_request':
                     #starting a utility_request thread
                     pass
                  elif msgbody['msgtype'] == 'scheduler_policy':
                     #starting a scheduler_policy excution thread
                     newthread = PolicyExcutionThread(msghead,msgbody)
                     newthread.start()
                  else:
                     pass# reserved to extending

                  #deleting the processed message in the messagelist
                  messagelist_loc.acquire()
                  indx = messagelist.index(msg)
                  messagelist.pop(indx)
                  print ('***Deleting a message from messagelist, there are %s messages wait for processing:' % len(messagelist))
                  messagelist_loc.release()   
           


#-----------The thead is to excute flow scheduling policy from controller-----
class PolicyExcutionThread(threading.Thread):
    def __init__(self,msghead,msgbody):
        super(PolicyExcutionThread, self).__init__()
        self.messagehead = msghead
        self.messagebody = copy.deepcopy(msgbody)

    def run(self):
        print ('***The scheduling policy received is:')
        print(self.messagebody)
        print("***Excuting scheduling policy...")
        global agentip,agentport,nicname,agent_host_password
        agent_ip_port = agentip+':'+ str(agentport)
        msgdic = self.messagebody
        if 'agentaddr' in msgdic.keys():
           if msgdic['agentaddr'] == agent_ip_port:
              if 'tc_prio' in msgdic.keys():
                  tc_str = msgdic['tc_prio']
                  tc.delete_sp_filters(nicname,agent_host_password)
                  tc.create_sp_filters(nicname,agent_host_password,tc_str)
                  indata = input("[PolicyExcution]please input anything:")
                  tc_str='1:192.168.1.4:60863,2:192.168.1.3:39535'
                  tc.delete_sp_filters(nicname,agent_host_password)
                  tc.create_sp_filters(nicname,agent_host_password,tc_str)

              if 'dscp_prio' in msgdic.keys():
                  dscp_prio = msgdic['dscp_prio']
                  iptables.create_iptables(dscp_prio,agent_host_password)


#===========================main function======================================
if __name__ == "__main__":
    #--------------read configurations------------------
    try:
        infile = open('config','r')
        host_indx = 0
        while True:
              line = infile.readline()
              if line!='':
                 linearray = line.split()
                 if linearray[0] == 'infofilepath':
                    infofilepath = linearray[1]
                 elif linearray[0] == 'node_role':
                    node_role = linearray[1]
                 elif linearray[0] =='controllerport':
                    controllerport = int(linearray[1])
                 elif linearray[0] == 'agentport':
                    agentport = int(linearray[1])
                 elif linearray[0] == 'controllerip':
                    controllerip = linearray[1]
                 elif linearray[0] == 'nicname':
                    nicname = linearray[1]
                 elif linearray[0] == 'heartbeatcycle':
                    heartbeatcycle = int(linearray[1])
                 elif linearray[0] == 'schedulingcycle':
                    schedulingcycle = int(linearray[1])
                 elif linearray[0] == 'policyupdatecycle':
                    policyupdatecycle = int(linearray[1])
                 elif linearray[0] == 'host_password':
                    agent_host_password = linearray[1]+'\n'
              else:
                 print("read config done.")
                 break
    except Exception as e:
        print(str(e))

    thread_list = []
 
    if node_role == "controller":

       #--start Hearteat thread-----------------------
       newthread = HeartBeatThread(1)
       newthread.start()
       thread_list.append(newthread)

       #--start flowscheduler thread------------------
       newthread = FlowShedulerThread(3)
       newthread.start()
       thread_list.append(newthread)
       #--start policy updating thread------------------
       newthread = PolicyUpdateThread(4)
       newthread.start()
       thread_list.append(newthread)

       #--start socket server of the controller-------
       contorllerip = get_ip(nicname)
       server = socketserver.ThreadingTCPServer((contorllerip,controllerport),Myserver)
       print ("socket server start.....")
       server.serve_forever()

    elif node_role == "agent":
       rstate = tc.create_sp_qdisc(nicname,agent_host_password)
       if rstate == False:
          print('[Error] create tc qdisc failed!')
          while True:
                time.sleep(10)
       #--send registor information to controller-----
       newthread = AgentRegistorThread(agentport)
       newthread.start()
       thread_list.append(newthread)

       #--start agent heartbeat thread----------------
       newthread = HeartBeatSending(5)
       newthread.start()
       thread_list.append(newthread)

       #--start message processing thread for the agent----
       newthread = MessageProcessThread()
       newthread.start()
       thread_list.append(newthread)

       #--start agent socket server to receive messages-------
       agentip = get_ip(nicname)
       server = socketserver.ThreadingTCPServer((agentip,agentport),Myserver)
       print ("socket server start.....")
       server.serve_forever()

