import os, sys
import subprocess
import shlex
import logging

DATEFMT ="[%Y-%m-%d %H:%M:%S]"
FORMAT = "%(asctime)s - %(name)s - %(message)s"
logging.basicConfig(level=logging.DEBUG,format=FORMAT,datefmt=DATEFMT,filename='scheduler.log')

logger = logging.getLogger('mlflowscheduler.iptables')

def run(cmd,password):
    command = shlex.split(cmd)
    command.insert(0,'-S')
    command.insert(0,'sudo')
    p = subprocess.Popen(command, bufsize=-1, stdout=subprocess.PIPE,
                         stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate(password.encode())
    if p.returncode == 0:
       logger.info('[{1}] {0}'.format(' '.join(command), p.returncode))
       #print("***A tc command is excuted successful")
    else:
       fmt = """[{1}] {0} [{2}]"""
       logger.error(fmt.format(' '.join(command), p.returncode, stderr.decode().strip()))
       if p.poll() is None:
          p.terminate()
          print("***A tc progress is killed")
    return stdout,p.returncode
#--------------------API of iptables--------------------------------
def create_iptables(dscp_prio_str,psw): 
    #step1. delete the existing iptables
    cmd_del_iptables = 'iptables -F OUTPUT -t mangle'
    stdout, returncode = run(cmd_del_iptables,psw)
    if returncode != 0:
       print("***del iptables command is failed!")
    #step2. create new iptables
    cmd_create_iptables = []
    prioarray = dscp_prio_str.split(',')
    for item in prioarray:
        prio_value,dst_ip,dst_port = item.split(':')
        prio_data = int(prio_value)
        prio_value = str(prio_data-1)
        if prio_data >= 3:
           prio_value = str(2)
        cmd_create_iptables.append('iptables -t mangle -A OUTPUT -d '+dst_ip+'/32 -p tcp --dport '+dst_port+' -j DSCP --set-dscp '+prio_value)
        cmd_create_iptables.append('iptables -t mangle -A OUTPUT -d '+dst_ip+'/32 -p udp --dport '+dst_port+' -j DSCP --set-dscp '+prio_value)
    
    for cmd in cmd_create_iptables:
        stdout, returncode = run(cmd,psw)
        #runout = 
        if returncode != 0:
           print("***create iptables command is failed!")
           print(stdout.decode())
           return False
    
    #print('[create_iptables] cmd_create_iptables: \n %s' % cmd_create_iptables)
    return True


