import os, sys,traceback
import os.path
import glob
import subprocess
import shlex
import logging
#import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit

DATEFMT ="[%Y-%m-%d %H:%M:%S]"
FORMAT = "%(asctime)s - %(name)s - %(message)s"
logging.basicConfig(level=logging.DEBUG,format=FORMAT,datefmt=DATEFMT,filename='scheduler.log')

logger = logging.getLogger('mlflowscheduler.readinfo')


def readjobinfo(filepath):
    retlist = readjobProgress(filepath)#return each chief worker's iteration step
    #print('retlist: ' + str(retlist))
    joblist = []
    jobinfo = {}
    '''
    source = os.getcwd()
    filepath = source +"/" + filepath
    filenames = glob.glob(filepath+"/jobconfig*")
    '''
    source = os.path.expanduser('~')
    filepath = source + '/' + filepath
    filenames = glob.glob(filepath+'/jobconfig*')

    if len(filenames) == 0:
       print('readjobinfo -> none: ')
       return joblist
    for filename in filenames:
        #print('readjobinfo -> filename: '+ filename)
        try:
            infile = open(filename,'r')
            lines = infile.readlines()
            nodeid = 0
            jobinfo = {}
            workerAddrs = ''
            serverAddrs = ''
            for line in lines:
                linearray = line.split(',')
                if len(linearray) < 2:
                   continue
                if linearray[0] == 'stage_size':
                   jobinfo['stageSizes'] = linearray[1]
                   jobinfo['localID'] = linearray[2]
                   jobinfo['maxStage'] = len(jobinfo['stageSizes'].split('-'))
                   jobinfo['weight'] = 1.0
                   #the active time is used to distinguish whether the job is active. 
                   if len(linearray) > 3:
                      jobinfo['activetime'] = linearray[3]
                if linearray[0] == 'model_size':
                   jobinfo['modelSize'] = linearray[1] 
                elif linearray[0] == 'Worker':
                   workerAddrs = workerAddrs + '-' +linearray[1]
                elif linearray[0] == 'Server':
                   serverAddrs = serverAddrs + '-' +linearray[1]
            workerAddrs = workerAddrs[1:]
            serverAddrs = serverAddrs[1:]
            jobinfo['workerAddrs'] = workerAddrs
            jobinfo['serverAddrs'] = serverAddrs
            
            
            if len(jobinfo) != 0:
               chiefinfo = filename.split('+')
               chiefaddr = chiefinfo[-2]+':'+chiefinfo[-1]
               jobinfo['chiefAddr'] = chiefaddr
               for item in retlist:
                   if item['chiefAddr'] == chiefaddr:
                      jobinfo['iterStep'] = item['iterStep']
                      break
               joblist.append(jobinfo)   
            infile.close()        
        except Exception as e:
            logger.info(' [1] failed to read file:{0}; The error is: {1}'.format(filename, repr(e)))

    return joblist

def readjobProgress(filepath):
    joblist = []
    workerinfo = {} #information from a worker per job
    source = os.path.expanduser('~')
    filepath = source + '/' + filepath
    filenames = glob.glob(filepath+'/worker*')

    if len(filenames) == 0:
       return joblist
    for filename in filenames:
        try:
            infile = open(filename,'r')
            lines = infile.readlines()
            jobinfo = {}
            for i in range(len(lines)-1,0,-1):
                line = lines[i]
                linearray = line.split(',')
                if len(linearray) < 3:
                   continue
                jobinfo['chiefAddr'] = linearray[0]
                jobinfo['iterStep'] = linearray[1]
                joblist.append(jobinfo) 
                break  
            infile.close()        
        except Exception as e:
            logger.info(' [1] failed to read file:{0}; The error is: {1}'.format(filename, repr(e)))

    return joblist

