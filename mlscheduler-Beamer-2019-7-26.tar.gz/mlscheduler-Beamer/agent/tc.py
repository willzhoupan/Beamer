import os, sys
import subprocess
import shlex
import logging

DATEFMT ="[%Y-%m-%d %H:%M:%S]"
FORMAT = "%(asctime)s - %(name)s - %(message)s"
logging.basicConfig(level=logging.DEBUG,format=FORMAT,datefmt=DATEFMT,filename='scheduler.log')

logger = logging.getLogger('mlflowscheduler.tc')

def run(cmd,password):
    command = shlex.split(cmd)
    command.insert(0,'-S')
    command.insert(0,'sudo')
    p = subprocess.Popen(command, bufsize=-1, stdout=subprocess.PIPE,
                         stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate(password.encode())
    if p.returncode == 0:
       logger.info('[{1}] {0}'.format(' '.join(command), p.returncode))
       #print("***A tc command is excuted successful")
    else:
       fmt = """[{1}] {0} [{2}]"""
       logger.error(fmt.format(' '.join(command), p.returncode, stderr.decode().strip()))
       if p.poll() is None:
          p.terminate()
          print("***A tc progress is killed")
    return stdout,p.returncode

#---------------------wrr queue functions----------------
def create_wrr_qdisc(nicname,psw):
    
    #step1. delete the filter and qdisc in the host
    cmd_del_filters = 'tc filter del dev '+nicname+' parent 10:0'
    cmd_del_qdisc = 'tc qdisc del dev '+nicname+' root'
    stdout, returncode = run(cmd_del_filters,psw)
    stdout, returncode = run(cmd_del_qdisc,psw)
    
    #step2. create qdisc in the host
    cmd_create_qdisc = []
    cmd_create_qdisc.append('tc qdisc add dev '+nicname+' root handle 1: htb default 1')
    cmd_create_qdisc.append('tc class add dev '+nicname+' parent 1: classid 1:1 htb rate 1000mbit')
    cmd_create_qdisc.append('tc qdisc add dev '+nicname+' parent 1:1 handle 10: cbq bandwidth 1000Mbit avpkt 1000 cell 8')
    cmd_create_qdisc.append('tc class add dev '+nicname+' parent 10:0 classid 10:1 cbq bandwidth 1000Mbit rate 1000Mbit weight 0.8Mbit prio 1 allot 1514 cell 8 maxburst 2 avpkt 1000')
    cmd_create_qdisc.append('tc class add dev '+nicname+' parent 10:0 classid 10:2 cbq bandwidth 1000Mbit rate 1000Mbit weight 0.1Mbit prio 2 allot 1514 cell 8 maxburst 2 avpkt 1000')
    cmd_create_qdisc.append('tc class add dev '+nicname+' parent 10:0 classid 10:3 cbq bandwidth 1000Mbit rate 1000Mbit weight 0.1Mbit prio 3 allot 1514 cell 8 maxburst 2 avpkt 1000')
    cmd_create_qdisc.append('tc qdisc add dev '+nicname+' parent 10:1 handle 101: sfq')
    cmd_create_qdisc.append('tc qdisc add dev '+nicname+' parent 10:2 handle 102: sfq')
    cmd_create_qdisc.append('tc qdisc add dev '+nicname+' parent 10:3 handle 103: sfq')
    for cmd in cmd_create_qdisc:
        stdout, returncode = run(cmd,psw)
        #runout = 
        if returncode != 0:
           print("***qdisc create command is failed!")
           print(stdout.decode())
           return False # create qdisc failed
    return True# create qdisc successully        

def delete_wrr_filters(nicname,psw):
    cmd_del_filters = 'tc filter del dev '+nicname+' parent 10:0'
    stdout, returncode = run(cmd_del_filters,psw)
    if returncode != 0:
       print("[tc.py Warning] delete filter command is failed!")
       print(stdout.decode())
       return False
    return True 

def create_wrr_filters(nicname,psw,tc_prio_str):
    cmd_create_filter = []
    prioarray = tc_prio_str.split(',')
    for item in prioarray:
        prio_value, dst_ip, dst_port = item.split(':')
        prio_data = int(prio_value)
        if prio_data >= 3:#prio value larger than 3 will be put in the 3rd queue
           prio_value = str(3)
        cmd_create_filter.append('tc filter add dev '+nicname+' parent 10:0 protocol ip prio 1 u32 match ip dst '+dst_ip+'/32 match ip dport '+dst_port+' 0xffff flowid 10:'+prio_value)
    
    for cmd in cmd_create_filter:
        stdout, returncode = run(cmd,psw)
        if returncode != 0:
           print("***create filter command is failed!")
           print(stdout.decode())
           return False
    return True       

#---------------------sp queue functions------------------
def create_sp_qdisc(nicname,psw):
    #step1. delete the filter and qdisc in the host
    cmd_del_filters = 'tc filter del dev '+nicname+' parent 10:0'
    cmd_del_qdisc = 'tc qdisc del dev '+nicname+' root'
    stdout, returncode = run(cmd_del_filters,psw)
    stdout, returncode = run(cmd_del_qdisc,psw)
    
    #step2. create qdisc in the host
    cmd_create_qdisc = []
    cmd_create_qdisc.append('tc qdisc add dev '+nicname+' root handle 1: htb default 1')
    cmd_create_qdisc.append('tc class add dev '+nicname+' parent 1: classid 1:1 htb rate 1000mbit')
    cmd_create_qdisc.append('tc qdisc add dev '+nicname+' parent 1:1 handle 10: prio bands 8')
    for cmd in cmd_create_qdisc:
        stdout, returncode = run(cmd,psw)
        if returncode != 0:
           print("***create qdisc command is failed!")
           print(stdout.decode())
           return False

    #step3. create class for the qdisc
    cmd_create_class = []
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:1 handle 11: pfifo')
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:2 handle 12: pfifo')
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:3 handle 13: pfifo')
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:4 handle 14: pfifo')
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:5 handle 15: pfifo')
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:6 handle 16: pfifo')
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:7 handle 17: pfifo')
    cmd_create_class.append('tc qdisc add dev '+nicname+' parent 10:8 handle 18: pfifo')
    for cmd in cmd_create_class:
        stdout, returncode = run(cmd,psw)
        if returncode != 0:
           print("***create qdisc class is failed!")
           print(stdout.decode())
           return False
    return True

def delete_sp_filters(nicname,psw):
    cmd_del_filters = 'tc filter del dev '+nicname+' parent 10:0'
    stdout, returncode = run(cmd_del_filters,psw)
    if returncode != 0:
       print("[tc.py Warning] delete filter command is failed!")
       print(stdout.decode())
       return False
    return True 

def create_sp_filters(nicname,psw,tc_prio_str):
    cmd_create_filter = []
    prioarray = tc_prio_str.split(',')
    for item in prioarray:
        prio_value, dst_ip, dst_port = item.split(':')
        prio_data = int(prio_value)
        if prio_data >= 8:#prio value larger than 8 will be put in the 8th queue
           prio_value = str(8)
        cmd_create_filter.append('tc filter add dev '+nicname+' parent 10:0 protocol ip prio '+prio_value+' u32 match ip dst '+dst_ip+'/32 match ip dport '+dst_port+' 0xffff flowid 10:'+prio_value)   
    for cmd in cmd_create_filter:
        stdout, returncode = run(cmd,psw)
        if returncode != 0:
           print("***create filter command is failed!")
           print(stdout.decode())
           return False
    return True

