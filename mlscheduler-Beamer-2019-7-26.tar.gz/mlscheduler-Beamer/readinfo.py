import os, sys,traceback
import os.path
import glob
import subprocess
import shlex
import logging
#import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit

DATEFMT ="[%Y-%m-%d %H:%M:%S]"
FORMAT = "%(asctime)s - %(name)s - %(message)s"
logging.basicConfig(level=logging.DEBUG,format=FORMAT,datefmt=DATEFMT,filename='scheduler.log')

logger = logging.getLogger('mlflowscheduler.readinfo')


def readjobinfo(filepath):
    joblist = []
    jobinfo = {}
    '''
    source = os.getcwd()
    filepath = source +"/" + filepath
    filenames = glob.glob(filepath+"/jobconfig*.csv")
    '''
    source = os.path.expanduser('~')
    filepath = source + '/' + filepath
    filenames = glob.glob(filepath+'/jobconfig*.csv')

    if len(filenames) == 0:
       return joblist
    for filename in filenames:
        try:
            infile = open(filename,'r')
            lines = infile.readlines()
            nodeid = 0
            jobinfo = {}
            for line in lines:
                linearray = line.split(',')
                if len(linearray) < 2:
                   continue
                if linearray[0] == 'Scheduler':
                   jobinfo['scheduler'] = linearray[1]
                   jobinfo['localID'] = linearray[2]
                   #the active time is used to distinguish whether the job is active. 
                   if len(linearray) > 3:
                      jobinfo['activetime'] = linearray[3]  
                elif linearray[0] == 'Worker':
                   nodekey = 'node'+str(nodeid)
                   jobinfo[nodekey] = 'worker:'+linearray[1]
                   nodeid = nodeid + 1
                elif linearray[0] == 'Server':
                   nodekey = 'node'+str(nodeid)
                   jobinfo[nodekey] = 'server:'+linearray[1]
                   nodeid = nodeid + 1
            if len(jobinfo) != 0:
               joblist.append(jobinfo)   
            infile.close()        
        except Exception as e:
            logger.info(' [1] failed to read file:{0}; The error is: {1}'.format(filename, repr(e)))

    return joblist

def fit_func1(x,a,b,c,d):
    return c-1/(a*x**d+b)
def fit_func2(x,a,b,c):
    return 1-(1/(a*x+b)+c)

def readworkerUtility(filepath,workeraddr,schedulingtime):
    return_state = 0
    return_utility = 0.0
    joblist = []
    jobinfo = {}
    '''
    source = os.getcwd()
    filepath = source +"/" + filepath
    '''
    source = os.path.expanduser('~')
    filepath = source + '/' + filepath

    worker_ip, worker_port = workeraddr.split(':',1)
    filename = 'worker+' + worker_ip + '+' + worker_port + '.csv'
    filename = filepath + '/' +filename
    if os.path.exists(filename)==False:
       return_state = 105 #the file is not exist or no this worker
       return_utility = 0
       return return_state, return_utility
    
    iternumber = []
    itertime = []
    acc = []
    validation = []
    timeline = []
    totaltime = 0
    try:
        infile = open(filename,'r')
        lines = infile.readlines()
        infile.close()
    except Exception as e:
        logger.info(' [101] failed to read file:{0}; The error is: {1}'.format(filename, repr(e)))
        return_state = 101#open file failed
        return_utility = 0
        return return_state,return_utility

    if len(lines) < 200:
       return_state = 102 #it's a new job's worker
       return_utility = 1.0 # a new job can run in the highest priority 
       return return_state, return_utility
    
    try:
        for line in lines:
            line = line.replace('\n','')
            if line == '':
               break
            linearray = line.split(',')
            
            if len(linearray) < 5:
               break
            if linearray[4]=='':
               break
            if linearray[0]=='IP:Port':
               continue
            else:

               if linearray[3] == 'None':# not the end of a epoch
                  workeraddr = linearray[0]
                  iternumber.append(int(linearray[1]))
                  acc.append(float(linearray[2]))
                  totaltime = totaltime + float(linearray[4])/60
                  itertime.append(float(linearray[4]))
                  timeline.append(totaltime)
                  validation.append(None)
               else:
                  validation.append(linearray[3])
    except Exception as e:
        return_state = 103 #there is something wrong, when reading training information
        return_utility = 0
        logger.info(' [103] failed to read file in lines:{0}; The error is: {1}'.format(line, repr(e)))

    try:
        #if the bandwidth is totally ocupied by the job, 
        #computing the increment of acc in the next scheduling cycle
        min_itertime = min(itertime[:-1])#minimum iteration time without last line
        predict_iters = int(schedulingtime/min_itertime)                  
        ydata = np.array(acc[:-1])

        iternum_now = len(ydata)
        xtime = np.arange(0,iternum_now,1)
        
        popt, pcov = curve_fit(fit_func1,xtime,ydata,p0=[0,1,1,0.5])
        a = popt[0]
        b = popt[1]
        c = popt[2]
        d = popt[3]
        utility = fit_func1(iternum_now+predict_iters,a,b,c,d)
        return_state = 100
        return_utility = utility - fit_func1(iternum_now,a,b,c,d)

        logger.info(' [100] Utility predict successfully; workeraddr:{0}, iternum_now:{1}, acc_now:{2}, predict_iters:{3}, predict_acc:{4}'.format(workeraddr,str(iternum_now),str(ydata[-1]),str(predict_iters),str(utility)))

    except Exception as e:
        return_state = 104 #there is something wrong, when predicting
        return_utility = 0
        logger.info(' [104] predicting error; The error is: {0}; traceback: {1}'.format(repr(e),traceback.format_exc()))        

    return return_state, return_utility  
 
'''
if __name__ == "__main__":

    readworkerUtility('data/','192.168.1.4:60449',1000)   
'''  

