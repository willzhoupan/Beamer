import numpy as np
import copy
class Fifolm(object):
      def __init__(self,**kwarg):
          #kwarg is used for extending
          for k,v in kwarg.items():
              setattr(self,k,v)      
             
      def GenerateStagePrio(self,jobList,net):
          hostNum = net.hostNum
          portLoadList = [0]*(2*hostNum)
          totalStageNum = 0
          # find completed jobs from jobList
          completedJobList = []
          for i in range(0,len(jobList)):
              job = jobList[i]
              if job.stageNow < 0:
                 completedJobList.append(job)
                 continue
          # delete completed jobs from jobList
          for job in completedJobList:
                 jobList.remove(job)
          
          #generate running stage orders
          sortList = []
          for job in jobList:
              sortList.append((job,job.stageStimes[job.stageNow])) 
          sortList.sort(key=lambda k:k[1],reverse = False)
          for i in range(0,len(sortList)):
              job = sortList[i][0]
              job.stageGlobalPrio[job.stageNow] = i 
              job.prio = i
                            
                             
          
         
           
