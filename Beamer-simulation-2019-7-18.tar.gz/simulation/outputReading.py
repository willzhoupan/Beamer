import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import numpy as np
import scipy.optimize
import random
import os
import re

#-------------------read file data--------------------------------------
timeUnit = 0.001
source = os.getcwd()
#filename = raw_input("please input the filename to read:")
#infile = open(source + filename,'r')
filename = '/output-Beamer'
infile = open(source + filename,'r')
stageList = []
stageNum = 0.0
earlyStageList = []
firstStageList = []
jobCompletionTimeList = []
jobNum = 0.0
print("read begin... \n")
while True:
      line = infile.readline()
      jobNum += 1
      if line!='':
         if jobNum%2 == 0:
            line = line[:-2]
            line = line[1:]
            ctimes = line.split(',')
            earlyStageList.append(float(ctimes[-2]))
            firstStageList.append(float(ctimes[-4]))
            jobCompletionTimeList.append(float(ctimes[-1]))
            stageNum += len(ctimes)
            for item in ctimes:
                stageList.append(float(item))
      else:
         jobNum -= 1
         print(str(jobNum) + " lines have been read")
         print('average stage completion time: '+str((sum(stageList)/stageNum)*timeUnit))
         print('early stage completion time(90%): '+str((sum(earlyStageList)/jobNum)*timeUnit))
         print('early stage completion time(90%): '+str((sum(firstStageList)/jobNum)*timeUnit))
         print('job completion time: '+str((sum(jobCompletionTimeList)/jobNum)*timeUnit))
         print("read done.")
         break
#plt.savefig('p2.png')
