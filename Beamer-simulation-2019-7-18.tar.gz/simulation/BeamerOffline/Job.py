import numpy as np
from config import dataUnit
from config import timeUnit
from config import hostNum
import config
import copy
from excutor import excutor
from Beamer import Beamer
class Job(object):
      def __init__(self,hNum,**kwarg):
          self.hostNum = hNum
          self.prio = 0 #init the priority of the job
          self.workerList = []
          self.serverList = []
          self.stageList = []
          self.weightList = []#used for beamer algorithm
          self.tailStage = 0#used for beamer algorithm
          self.stageCtimes = []
          self.stageNow = 0
          self.iterNow = 0.0
          # gradient computing
          self.gaptime = 0.0
          self.flowsEmpty = np.zeros((hNum,hNum),dtype=float)
          self.flowsNow = np.zeros((hNum,hNum),dtype=float)
          
          #kwarg = {'JobId':1,'modelName':'DenseNet','modelSize':'576-MB','workerHosts':'0-1-2',
          #         'serverHosts':'3-4','stageSizes':'200-200-400','ctime':2,'weight':1.0,'maxStage':3}
          for k,v in kwarg.items():
              setattr(self,k,v)
         
          workers = self.workerHosts.split('-')
          for item in workers:
              self.workerList.append(int(item))
 
          servers = self.serverHosts.split('-')
          for item in servers:
              self.serverList.append(int(item))
         
          stages = self.stageSizes.split('-')
          for item in stages:
              self.stageList.append(float(item))
          #Init all stage_weight equals to self.weight
          for i in range(0,len(stages)):
              temp = 0.0
              #computing w_jk
              for j in range(i,len(stages)):
                  temp += 1/self.stageList[j]
              temp = temp*self.weight 
              self.weightList.append(temp)
          self.stageGlobalPrio = np.zeros(len(self.stageList),dtype=int)
          self.tailStage = len(self.stageList) - 1

          fsize,funit = self.modelSize.split('-')
          self.flowSize = float(fsize)/(dataUnit*len(self.serverList))
          self.ctime = self.ctime/timeUnit
          #generate a coflow
          self.GeneratePushFlows()
          self.GeneratePullFlows() 

      def GeneratePushFlows(self):
          for worker in self.workerList:
              for server in self.serverList:
                  if worker<self.hostNum and server<self.hostNum:
                     #update worker->server data size
                     self.flowsNow[worker][server] += self.flowSize

      def GeneratePullFlows(self):
          for server in self.serverList:
              for worker in self.workerList:
                  if worker<self.hostNum and server<self.hostNum:
                     #update server->worker data size
                     self.flowsNow[server][worker] += self.flowSize
      '''
      def GenerateFlows(self):
          self.GeneratePushFlows()
          self.GeneratePullFlows()
      '''   
   
      def UpdateState(self,timeNow):
          if self.stageNow < 0:
                return 'completed!'          
          if (self.flowsNow == self.flowsEmpty).all():
             #all flows in this iteration have been transfered
             #update job stage and gaptime
             stage = -1
             if self.gaptime <= 0:
                self.iterNow += 1
                #Check job stage
                for i in range(0,len(self.stageList)):
                    if self.iterNow < self.stageList[i]:
                       stage = i
                       break
                if stage < 0 or stage > (self.maxStage-1): #job completed
                   self.stageNow = -1
                   self.stageCtimes.append(timeNow)
                   return 'completed!'
                else:
                   stageOld = self.stageNow
                   self.stageNow = stage
                   self.prio = self.stageGlobalPrio[self.stageNow]
                   self.gaptime = self.ctime
                   if self.gaptime <= 0:
                      self.GeneratePushFlows()
                      self.GeneratePullFlows()
                   if stageOld < stage:
                      self.stageCtimes.append(timeNow)
                      return 'stage_change!' 
                   return 'coflow_over'                     
                   #print('gaptime: '+str(self.gaptime))
             #Waiting for computing gradients
             else:
                self.gaptime -= 1
                self.prio = self.stageGlobalPrio[self.stageNow]
                #Gradients computing is finished
                if self.gaptime <= 0:
                   self.GeneratePushFlows()
                   self.GeneratePullFlows()
                   return 'gaptime_over'
                return 'gaptime_during'
          else:
              self.prio = self.stageGlobalPrio[self.stageNow]
              return 'coflow_tranfering'     
             
      def TransferData(self):
          for server in self.serverList:
              for worker in self.workerList:
                  self.flowsNow[worker][server] -= 1
                  self.flowsNow[server][worker] -= 1
                  if self.flowsNow[worker][server] < 0:
                     self.flowsNow[worker][server] = 0
                  if self.flowsNow[server][worker] < 0:
                     self.flowsNow[server][worker] = 0
                   

if __name__ == "__main__":
      joblist = []
      schedulelist = []
      dcn = excutor()
      scheduler = Beamer()
      kwarg = {'JobId':1,'modelName':'DenseNet','modelSize':'100-MB','workerHosts':'1-2',
                   'serverHosts':'3-4','stageSizes':'10-20-40','ctime':0.01,'weight':1.0}
      kwarg1 = {'JobId':2,'modelName':'hotNet','modelSize':'100-MB','workerHosts':'1-2',
                   'serverHosts':'3-4','stageSizes':'10-40-80','ctime':0.01,'weight':1.0}
      kwarg2 = {'JobId':3,'modelName':'nextNet','modelSize':'100-MB','workerHosts':'1-2',
                   'serverHosts':'3-4','stageSizes':'10-20-60','ctime':0.02,'weight':1.0}
      densNetJob = Job(hostNum,**kwarg)
      hotNetJob = Job(hostNum,**kwarg1)
      nextNetJob = Job(hostNum,**kwarg2)
      schedulelist.append(densNetJob)
      schedulelist.append(hotNetJob)
      schedulelist.append(nextNetJob)
      scheduler.GenerateStagePrio(schedulelist,dcn)
      print('densNetJob:')
      print(densNetJob.stageGlobalPrio)
      print('hotNetJob:')
      print(hotNetJob.stageGlobalPrio)
      print('nextNetJob:')
      print(nextNetJob.stageGlobalPrio)
      #stage changed flag
      stageChageFlag = False
      #off-line schedule
      for timeNow in range(0,10000):
          #delete finished jobs from schedulelist
          unscheduledJobNum = len(schedulelist)
          if unscheduledJobNum == 0 :
             print('All job have completed!')
             break
          completedJobList = []
          #update states of all jobs
          for i in range(0,unscheduledJobNum):
              job = schedulelist[i]
              state = job.UpdateState(timeNow)
              if state == 'completed!':
                 completedJobList.append(job)
                 stageChageFlag = True
                 continue
              elif state == 'stage_change!':
                 stageChageFlag = True
          #delete completed jobs from schedulelist
          for cjob in completedJobList:
                 schedulelist.remove(cjob)
             
          dcn.TransferData(schedulelist)

      print(densNetJob.stageCtimes)
      print(hotNetJob.stageCtimes)
      print(nextNetJob.stageCtimes)
      '''
      print(densNetJob.flowsNow)
      #computing egress bandwidth
      bwSrc = np.zeros((hostNum,hostNum),dtype=float)
      for i in range(0,hostNum):
              src = densNetJob.flowsNow[i]
              dtemp = np.nonzero(src)
              dsts = dtemp[0]
              egressBw = 1/len(dsts)
              for j in dsts:
                  bwSrc[i][j] = egressBw
      #computing ingress bandwidth
      bwDst = np.zeros((hostNum,hostNum),dtype=float)
      for j in range(0,hostNum):
              dst = densNetJob.flowsNow[:,j]
              stemp = np.nonzero(dst)
              srcs = stemp[0]
              ingressBw = 0.5/len(srcs)
              for i in srcs:
                  bwDst[i][j] = ingressBw
       #computing point to point bandwidth
      bw = np.zeros((hostNum,hostNum),dtype=float)
      for i in range(0,hostNum):
              for j in range(0,hostNum):
                  bw[i][j] = min(bwSrc[i][j],bwDst[i][j])
                  if bw[i][j] == 0.:
                     bw[i][j] = float('inf')
      print(bw)
      print(densNetJob.flowsNow)
      row,col = divmod(np.argmin(bw),np.shape(bw)[1])
      print(divmod(np.argmin(bw),np.shape(bw)[1]))
      densNetJob.flowsNow[row][col] -= bw[row][col]
      print(densNetJob.flowsNow)
      '''
      '''
      print(densNetJob.flowsNow)
      for i in range(0,hostNum):
          src = densNetJob.flowsNow[i]
          dsts = np.nonzero(src)
          print('src: '+str(src)+'; dsts: '+ str(dsts[0]))
          for item in dsts[0]:
              print(item)
      '''      

      
      '''    
      kwarg1 = {'JobId':2,'modelName':'nextNet','modelSize':'500-MB','workerHosts':'0-1-2',
                   'serverHosts':'3-4','stageSizes':'20-40-80','ctime':0.000,'weight':1} 
      nextNetJob = Job(hostNum,**kwarg1)
      nextNetJob.prio=2
      a = [(nextNetJob,nextNetJob.prio),(densNetJob,densNetJob.prio)]
      a.sort(key=lambda k:k[1],reverse = True)
      print(densNetJob.stageCtimes)
      print(densNetJob.stageNow)
      '''


