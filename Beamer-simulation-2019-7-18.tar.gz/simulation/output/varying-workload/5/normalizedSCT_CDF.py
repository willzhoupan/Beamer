import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import numpy as np
import scipy.optimize
import random
import os
import re
import glob
#-------------------copy notArrivingJobs from /BeamerOnline/config.py---
hostNum = 10 #Host number
bandwidth = 10.0#Gbps
dataUnit = 10.0 #MB
timeUnit = dataUnit/(bandwidth*1e3/8) #Seconds
notArrivingJobs = [[0, {"maxStage": 4, "workerHosts": "0-1-2", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "3-4-5", "JobId": 0, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [0, {"maxStage": 4, "workerHosts": "1", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "2", "JobId": 1, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [0, {"maxStage": 4, "workerHosts": "2-3-4-5-6-7", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "8-9-0-1-2-3", "JobId": 2, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [1, {"maxStage": 2, "workerHosts": "3-4-5-6-7-8", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "9-0-1-2-3-4", "JobId": 3, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [15.731842808417715, {"maxStage": 3, "workerHosts": "4-5", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "6-7", "JobId": 4, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [15.731842808417715, {"maxStage": 3, "workerHosts": "5-6-7-8-9", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2-3-4", "JobId": 5, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [15.731842808417715, {"maxStage": 5, "workerHosts": "6-7-8", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "9-0-1", "JobId": 6, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [19.017075372019246, {"maxStage": 2, "workerHosts": "7", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "8", "JobId": 7, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [28.109691213110207, {"maxStage": 2, "workerHosts": "8-9-0-1", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3-4-5", "JobId": 8, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [41.401218720127325, {"maxStage": 6, "workerHosts": "9-0-1", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3-4", "JobId": 9, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [42.401218720127325, {"maxStage": 3, "workerHosts": "0-1", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3", "JobId": 10, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [42.401218720127325, {"maxStage": 2, "workerHosts": "1-2-3-4-5", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "6-7-8-9-0", "JobId": 11, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [42.401218720127325, {"maxStage": 1, "workerHosts": "2-3-4-5", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "6-7-8-9", "JobId": 12, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [44.77852666610346, {"maxStage": 1, "workerHosts": "3-4", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6", "JobId": 13, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [44.77852666610346, {"maxStage": 6, "workerHosts": "4-5-6", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9", "JobId": 14, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [44.77852666610346, {"maxStage": 4, "workerHosts": "5-6-7-8-9", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2-3-4", "JobId": 15, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [47.00095857529485, {"maxStage": 5, "workerHosts": "6-7-8", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "9-0-1", "JobId": 16, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [47.00095857529485, {"maxStage": 3, "workerHosts": "7-8-9-0-1-2", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "3-4-5-6-7-8", "JobId": 17, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [47.00095857529485, {"maxStage": 3, "workerHosts": "8-9-0", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "1-2-3", "JobId": 18, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [47.00095857529485, {"maxStage": 2, "workerHosts": "9-0", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "1-2", "JobId": 19, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [47.00095857529485, {"maxStage": 2, "workerHosts": "0-1", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3", "JobId": 20, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [72.98448686329509, {"maxStage": 1, "workerHosts": "1-2-3-4-5-6", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9-0-1-2", "JobId": 21, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [75.37984539161766, {"maxStage": 5, "workerHosts": "2-3-4", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6-7", "JobId": 22, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [75.37984539161766, {"maxStage": 6, "workerHosts": "3-4-5-6-7", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "8-9-0-1-2", "JobId": 23, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [76.37984539161766, {"maxStage": 1, "workerHosts": "4-5-6-7", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "8-9-0-1", "JobId": 24, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [76.37984539161766, {"maxStage": 1, "workerHosts": "5-6", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8", "JobId": 25, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [79.18390464156504, {"maxStage": 1, "workerHosts": "6-7", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "8-9", "JobId": 26, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [79.18390464156504, {"maxStage": 6, "workerHosts": "7-8-9", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2", "JobId": 27, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [80.18390464156504, {"maxStage": 5, "workerHosts": "8-9-0-1", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3-4-5", "JobId": 28, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [80.18390464156504, {"maxStage": 4, "workerHosts": "9-0-1-2-3", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "4-5-6-7-8", "JobId": 29, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [80.18390464156504, {"maxStage": 2, "workerHosts": "0-1-2-3-4", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6-7-8-9", "JobId": 30, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [81.18390464156504, {"maxStage": 1, "workerHosts": "1-2-3-4", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6-7-8", "JobId": 31, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [81.18390464156504, {"maxStage": 2, "workerHosts": "2-3-4-5-6", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9-0-1", "JobId": 32, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [84.62511929847989, {"maxStage": 2, "workerHosts": "3-4-5-6", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9-0", "JobId": 33, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [85.62511929847989, {"maxStage": 1, "workerHosts": "4-5-6", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9", "JobId": 34, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [88.12329990794292, {"maxStage": 4, "workerHosts": "5-6-7-8-9", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2-3-4", "JobId": 35, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [102.50943201481792, {"maxStage": 3, "workerHosts": "6-7-8-9-0", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "1-2-3-4-5", "JobId": 36, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [107.52353607661223, {"maxStage": 5, "workerHosts": "7-8-9", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2", "JobId": 37, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [114.47201749838351, {"maxStage": 3, "workerHosts": "8-9-0-1-2-3", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "4-5-6-7-8-9", "JobId": 38, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [114.47201749838351, {"maxStage": 4, "workerHosts": "9-0-1-2-3-4", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6-7-8-9-0", "JobId": 39, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}]]
jobInfoList = []
for item in notArrivingJobs:
    jobInfo = item[1]
    jobid = jobInfo['JobId']
    modelName = jobInfo['modelName']
    workerlist = jobInfo['workerHosts'].split('-')
    serverlist = jobInfo['serverHosts'].split('-')
    sizestr,unit = jobInfo['modelSize'].split('-')
    modelSize = float(sizestr)
    perflowsize = modelSize/len(serverlist)
    stagelist = jobInfo['stageSizes'].split('-')
    stageOCTlist = []
    for i in range(0,jobInfo['maxStage']):
        iterNum = float(stagelist[i])
        stagetime = item[0]+len(workerlist)*perflowsize*iterNum/(bandwidth*1e3/8)
        stageOCTlist.append(stagetime) 
    jobInfoList.append((jobid,modelName,stageOCTlist))
#-------------------read file data--------------------------------------
lineset = ['o','v','^','<','>','s','p','*','h','H','+','x','D','d','|']
colorset =['b','g','r','c','m','y','k'] 
colorindex = int(random.uniform(0,len(colorset)))

models = ['DeepSpeech2','ResNet152','AlexNet','VGG19']

source = os.getcwd()
filepath = raw_input("please input the file path:")
filepath = source + filepath
filenames = glob.glob(filepath+"/output-*")
for filename in filenames:
    #update data
    jobInfoList = []
    for item in notArrivingJobs:
        jobInfo = item[1]
        jobid = jobInfo['JobId']
        modelName = jobInfo['modelName']
        workerlist = jobInfo['workerHosts'].split('-')
        serverlist = jobInfo['serverHosts'].split('-')
        sizestr,unit = jobInfo['modelSize'].split('-')
        modelSize = float(sizestr)
        perflowsize = modelSize/len(serverlist)
        stagelist = jobInfo['stageSizes'].split('-')
        stageOCTlist = []
        for i in range(0,jobInfo['maxStage']):
            iterNum = float(stagelist[i])
            stagetime = item[0]+len(workerlist)*perflowsize*iterNum/(bandwidth*1e3/8)
            stageOCTlist.append(stagetime) 
        jobInfoList.append((jobid,modelName,stageOCTlist))
    
    #read files
    infile = open(filename,'r')
    namearray = filename.split('/')
    lablename = namearray[-1]
    stageList = []
    stageNum = 0.0
    earlyStageList = []
    firstStageList = []
    slowdownList = []
    jobCompletionTimeList = []
    jobStageCtimeList = []
    lineNum = 0.0
    print(lablename+" read begin... \n")
    while True:
          line = infile.readline()
          lineNum += 1
          if line!='':
             if (lineNum-1)%2 == 0:
                linearray = line.split(',')
                jobid = int(linearray[1])
                jobmodelname = linearray[0]           
             elif lineNum%2 == 0:
                line = line[:-2]
                line = line[1:]
                ctimes = line.split(',')
                if len(ctimes) >= 4:
                   earlyStageList.append(float(ctimes[3]))
                if len(ctimes) >= 3:
                   firstStageList.append(float(ctimes[2]))
                jobCompletionTimeList.append(float(ctimes[-1]))
                stageNum += len(ctimes)
                jobInfoItem = jobInfoList[jobid]
                #OCTtempList = []
                ctimelist = []
                if jobInfoItem[0] == jobid:
                   OCTtempList = jobInfoItem[2]
                   for i in range(0,len(ctimes)):
                       ctimelist.append(float(ctimes[i]))
                       OCTtempList[i] = float(ctimes[i])*timeUnit/OCTtempList[i]
                       slowdownList.append(OCTtempList[i])
                   jobStageCtimeList.append((jobmodelname,ctimelist))
                else:
                   print('jobid is wrong! check the program!!!')
                for item in ctimes:
                    stageList.append(float(item))
          else:
             #computing slowdown CDF
             slowdownset = set(slowdownList)
             sdsetlist = list(slowdownset)
             sdsetlist.sort()
             sdNumlist = []
             for i in range(0,len(sdsetlist)):
                 sdNumlist.append(slowdownList.count(sdsetlist[i]))
             sdProlist = []
             for i in range(0,len(sdsetlist)):
                 sdProlist.append(sdNumlist[i]/stageNum)
             sdPros = np.array(sdProlist)
             slowdownCDF = sdPros.cumsum(0)
             #plot CDF
             lineindex = int(random.uniform(0,len(lineset)))
             linetype = lineset[lineindex]
             #colorindex = int(random.uniform(0,len(colorset)))
             colorindex += 1
             colorindex = colorindex%len(colorset)
             colortype = colorset[colorindex]
             #linemark =  colortype+'-'+linetype
             linemark =  colortype+'-'
             plt.plot(sdsetlist, slowdownCDF,linemark,label=lablename)

             jobNum = (lineNum-1)/2
             print(str(jobNum) + " jobs have been read")
             print(lablename+" read done.")
             print('average stage slowdown: '+str(sum(slowdownList)/len(slowdownList)))
             print('average stage completion time: '+str((sum(stageList)/stageNum)*timeUnit))
             print('early stage completion time(90%): '+str((sum(earlyStageList)/len(earlyStageList))*timeUnit))
             print('early stage completion time(50%): '+str((sum(firstStageList)/len(firstStageList))*timeUnit))
             print('job completion time: '+str((sum(jobCompletionTimeList)/len(jobCompletionTimeList))*timeUnit))
             print('-------------------------------')
             #computing average slowdown time of different stages in each job
             sdFilename = 'slowdown-'+lablename
             sdout = open(source +'/'+sdFilename,'w')
             sdout.write('average stage slowdown\n') 
             for mdname in models:
                 stageslowdownbuf = []
                 for item in jobInfoList:
                     if item[1] != mdname:
                        continue
                     stageslowdownbuf.append(item[2])
                 #computing max stage numbers
                 maxstageNum = 0
                 for item in stageslowdownbuf:
                     if maxstageNum < len(item):
                        maxstageNum = len(item)
                 #computing average slowdown for each stage
                 averageSlowdown = []
                 for j in range(0,maxstageNum):
                     jobNum = 0
                     slowdownSum = 0
                     for item in stageslowdownbuf:
                         if j >= len(item):
                            continue
                         jobNum += 1
                         slowdownSum += item[j]
                     averageSlowdown.append(slowdownSum/jobNum)
                 #write to file
                 sdout.write(mdname+': '+str(averageSlowdown))
                 sdout.write('\n')
                 print('-----average stage slowdown for each model------------') 
                 print(mdname+': '+str(averageSlowdown))
             sdout.close()
             #computing average stage time of different stages in each job
             stFilename = 'stagetime-'+lablename
             stout = open(source +'/'+stFilename,'w')
             stout.write('average stage time\n') 
             for mdname in models:
                 stagetimebuf = []
                 for item in jobStageCtimeList:
                     if item[0] != mdname:
                        continue
                     stagetimebuf.append(item[1])
                 #computing max stage numbers
                 maxstageNum = 0
                 for item in stagetimebuf:
                     if maxstageNum < len(item):
                        maxstageNum = len(item)
                 #computing average slowdown for each stage
                 averagestagetime = []
                 for j in range(0,maxstageNum):
                     jobNum = 0
                     stagetimeSum = 0
                     for item in stagetimebuf:
                         if j >= len(item):
                            continue
                         jobNum += 1
                         stagetimeSum += item[j]
                     averagestagetime.append(stagetimeSum*timeUnit/jobNum)
                 #write to file
                 stout.write(mdname+': '+str(averagestagetime))
                 stout.write('\n')
                 print('-----average stage time for each model------------')
                 print(mdname+': '+str(averagestagetime))        
             stout.close()       
             #write result to files
             cdfFilename = 'cdf-'+lablename
             fout = open(source +'/'+cdfFilename,'w')
             fout.write('average stage slowdown: '+str(sum(slowdownList)/len(slowdownList))+'\n')
             fout.write('average stage completion time: '+str((sum(stageList)/len(stageList))*timeUnit)+'\n')
             fout.write('early stage completion time(90%): '+str((sum(earlyStageList)/len(earlyStageList))*timeUnit)+'\n')
             fout.write('early stage completion time(50%): '+str((sum(firstStageList)/len(firstStageList))*timeUnit)+'\n')
             fout.write('job completion time: '+str((sum(jobCompletionTimeList)/len(jobCompletionTimeList))*timeUnit)+'\n')
             fout.write('x: '+'\n')
             fout.write(str(sdsetlist)+'\n')
             fout.write('y: '+'\n')
             fout.write(str(slowdownCDF)+'\n')
             fout.close()
             break
plt.xlabel('Normalized Stage Slowdown')
plt.ylabel('CDF')
plt.legend(loc=4)
plt.title('Stage Slowdown CDF')
plt.show()
#plt.savefig('p2.png')
