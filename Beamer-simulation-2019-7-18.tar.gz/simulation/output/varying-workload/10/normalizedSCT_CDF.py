import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import numpy as np
import scipy.optimize
import random
import os
import re
import glob
#-------------------copy notArrivingJobs from /BeamerOnline/config.py---
hostNum = 10 #Host number
bandwidth = 10.0#Gbps
dataUnit = 10.0 #MB
timeUnit = dataUnit/(bandwidth*1e3/8) #Seconds
notArrivingJobs = [[0, {"maxStage": 6, "workerHosts": "0-1", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3", "JobId": 0, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [0, {"maxStage": 6, "workerHosts": "1-2-3-4", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6-7-8", "JobId": 1, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [2.5361009337487874, {"maxStage": 1, "workerHosts": "2-3", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "4-5", "JobId": 2, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [2.5361009337487874, {"maxStage": 5, "workerHosts": "3-4-5-6", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9-0", "JobId": 3, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [2.5361009337487874, {"maxStage": 2, "workerHosts": "4-5-6-7-8-9", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2-3-4-5", "JobId": 4, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [2.5361009337487874, {"maxStage": 6, "workerHosts": "5-6-7", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "8-9-0", "JobId": 5, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [3.810438229982191, {"maxStage": 5, "workerHosts": "6-7-8-9-0-1", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3-4-5-6-7", "JobId": 6, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [5.735976276363493, {"maxStage": 4, "workerHosts": "7-8-9-0-1", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3-4-5-6", "JobId": 7, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [5.735976276363493, {"maxStage": 1, "workerHosts": "8-9-0-1", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3-4-5", "JobId": 8, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [5.735976276363493, {"maxStage": 6, "workerHosts": "9-0-1-2", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "3-4-5-6", "JobId": 9, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [5.735976276363493, {"maxStage": 2, "workerHosts": "0-1-2", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "3-4-5", "JobId": 10, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [5.735976276363493, {"maxStage": 6, "workerHosts": "1-2-3-4-5-6", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9-0-1-2", "JobId": 11, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [5.735976276363493, {"maxStage": 4, "workerHosts": "2", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "3", "JobId": 12, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [5.735976276363493, {"maxStage": 4, "workerHosts": "3-4-5", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "6-7-8", "JobId": 13, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [8.338178239131416, {"maxStage": 5, "workerHosts": "4-5", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "6-7", "JobId": 14, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [9.43552810379496, {"maxStage": 6, "workerHosts": "5-6-7-8-9-0", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "1-2-3-4-5-6", "JobId": 15, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [9.43552810379496, {"maxStage": 6, "workerHosts": "6-7-8-9", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2-3", "JobId": 16, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [10.634255743268424, {"maxStage": 4, "workerHosts": "7-8-9-0-1", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "2-3-4-5-6", "JobId": 17, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [10.634255743268424, {"maxStage": 1, "workerHosts": "8", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "9", "JobId": 18, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [10.634255743268424, {"maxStage": 2, "workerHosts": "9-0-1-2", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "3-4-5-6", "JobId": 19, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [12.539785404483455, {"maxStage": 4, "workerHosts": "0-1-2-3", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "4-5-6-7", "JobId": 20, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [12.539785404483455, {"maxStage": 5, "workerHosts": "1-2-3-4", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6-7-8", "JobId": 21, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [12.539785404483455, {"maxStage": 6, "workerHosts": "2-3-4-5-6-7", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "8-9-0-1-2-3", "JobId": 22, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [12.539785404483455, {"maxStage": 1, "workerHosts": "3-4-5", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "6-7-8", "JobId": 23, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [12.539785404483455, {"maxStage": 5, "workerHosts": "4-5-6", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "7-8-9", "JobId": 24, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [12.539785404483455, {"maxStage": 2, "workerHosts": "5", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "6", "JobId": 25, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [19.44428599252065, {"maxStage": 3, "workerHosts": "6", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "7", "JobId": 26, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [19.44428599252065, {"maxStage": 6, "workerHosts": "7-8-9-0", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "1-2-3-4", "JobId": 27, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [19.44428599252065, {"maxStage": 2, "workerHosts": "8", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "9", "JobId": 28, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [23.74390979975894, {"maxStage": 1, "workerHosts": "9-0-1-2-3", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "4-5-6-7-8", "JobId": 29, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [23.74390979975894, {"maxStage": 5, "workerHosts": "0-1-2-3-4-5", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "6-7-8-9-0-1", "JobId": 30, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [29.158060397706727, {"maxStage": 5, "workerHosts": "1-2-3-4", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6-7-8", "JobId": 31, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [29.158060397706727, {"maxStage": 3, "workerHosts": "2-3", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "4-5", "JobId": 32, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [29.158060397706727, {"maxStage": 1, "workerHosts": "3-4", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "5-6", "JobId": 33, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [32.83419746778055, {"maxStage": 4, "workerHosts": "4", "modelName": "AlexNet", "ctime": 0.0, "weight": 1.0, "serverHosts": "5", "JobId": 34, "modelSize": "250.0-MB", "stageSizes": "10-20-40-80-160-960"}], [40.414418278395836, {"maxStage": 3, "workerHosts": "5-6-7-8-9", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1-2-3-4", "JobId": 35, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [40.414418278395836, {"maxStage": 1, "workerHosts": "6-7", "modelName": "VGG19", "ctime": 0.0, "weight": 1.0, "serverHosts": "8-9", "JobId": 36, "modelSize": "580.0-MB", "stageSizes": "10-20-40-80-160-960"}], [40.414418278395836, {"maxStage": 2, "workerHosts": "7-8-9-0", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "1-2-3-4", "JobId": 37, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}], [40.414418278395836, {"maxStage": 6, "workerHosts": "8-9", "modelName": "DeepSpeech2", "ctime": 0.0, "weight": 1.0, "serverHosts": "0-1", "JobId": 38, "modelSize": "160.0-MB", "stageSizes": "10-20-40-80-160-960"}], [48.044998116317814, {"maxStage": 6, "workerHosts": "9-0", "modelName": "ResNet152", "ctime": 0.0, "weight": 1.0, "serverHosts": "1-2", "JobId": 39, "modelSize": "230.0-MB", "stageSizes": "10-20-40-80-160-960"}]]
jobInfoList = []
for item in notArrivingJobs:
    jobInfo = item[1]
    jobid = jobInfo['JobId']
    modelName = jobInfo['modelName']
    workerlist = jobInfo['workerHosts'].split('-')
    serverlist = jobInfo['serverHosts'].split('-')
    sizestr,unit = jobInfo['modelSize'].split('-')
    modelSize = float(sizestr)
    perflowsize = modelSize/len(serverlist)
    stagelist = jobInfo['stageSizes'].split('-')
    stageOCTlist = []
    for i in range(0,jobInfo['maxStage']):
        iterNum = float(stagelist[i])
        stagetime = item[0]+len(workerlist)*perflowsize*iterNum/(bandwidth*1e3/8)
        stageOCTlist.append(stagetime) 
    jobInfoList.append((jobid,modelName,stageOCTlist))
#-------------------read file data--------------------------------------
lineset = ['o','v','^','<','>','s','p','*','h','H','+','x','D','d','|']
colorset =['b','g','r','c','m','y','k'] 
colorindex = int(random.uniform(0,len(colorset)))

models = ['DeepSpeech2','ResNet152','AlexNet','VGG19']

source = os.getcwd()
filepath = raw_input("please input the file path:")
filepath = source + filepath
filenames = glob.glob(filepath+"/output-*")
for filename in filenames:
    #update data
    jobInfoList = []
    for item in notArrivingJobs:
        jobInfo = item[1]
        jobid = jobInfo['JobId']
        modelName = jobInfo['modelName']
        workerlist = jobInfo['workerHosts'].split('-')
        serverlist = jobInfo['serverHosts'].split('-')
        sizestr,unit = jobInfo['modelSize'].split('-')
        modelSize = float(sizestr)
        perflowsize = modelSize/len(serverlist)
        stagelist = jobInfo['stageSizes'].split('-')
        stageOCTlist = []
        for i in range(0,jobInfo['maxStage']):
            iterNum = float(stagelist[i])
            stagetime = item[0]+len(workerlist)*perflowsize*iterNum/(bandwidth*1e3/8)
            stageOCTlist.append(stagetime) 
        jobInfoList.append((jobid,modelName,stageOCTlist))
    
    #read files
    infile = open(filename,'r')
    namearray = filename.split('/')
    lablename = namearray[-1]
    stageList = []
    stageNum = 0.0
    earlyStageList = []
    firstStageList = []
    slowdownList = []
    jobCompletionTimeList = []
    jobStageCtimeList = []
    lineNum = 0.0
    print(lablename+" read begin... \n")
    while True:
          line = infile.readline()
          lineNum += 1
          if line!='':
             if (lineNum-1)%2 == 0:
                linearray = line.split(',')
                jobid = int(linearray[1])
                jobmodelname = linearray[0]           
             elif lineNum%2 == 0:
                line = line[:-2]
                line = line[1:]
                ctimes = line.split(',')
                if len(ctimes) >= 4:
                   earlyStageList.append(float(ctimes[3]))
                if len(ctimes) >= 3:
                   firstStageList.append(float(ctimes[2]))
                jobCompletionTimeList.append(float(ctimes[-1]))
                stageNum += len(ctimes)
                jobInfoItem = jobInfoList[jobid]
                #OCTtempList = []
                ctimelist = []
                if jobInfoItem[0] == jobid:
                   OCTtempList = jobInfoItem[2]
                   for i in range(0,len(ctimes)):
                       ctimelist.append(float(ctimes[i]))
                       OCTtempList[i] = float(ctimes[i])*timeUnit/OCTtempList[i]
                       slowdownList.append(OCTtempList[i])
                   jobStageCtimeList.append((jobmodelname,ctimelist))
                else:
                   print('jobid is wrong! check the program!!!')
                for item in ctimes:
                    stageList.append(float(item))
          else:
             #computing slowdown CDF
             slowdownset = set(slowdownList)
             sdsetlist = list(slowdownset)
             sdsetlist.sort()
             sdNumlist = []
             for i in range(0,len(sdsetlist)):
                 sdNumlist.append(slowdownList.count(sdsetlist[i]))
             sdProlist = []
             for i in range(0,len(sdsetlist)):
                 sdProlist.append(sdNumlist[i]/stageNum)
             sdPros = np.array(sdProlist)
             slowdownCDF = sdPros.cumsum(0)
             #plot CDF
             lineindex = int(random.uniform(0,len(lineset)))
             linetype = lineset[lineindex]
             #colorindex = int(random.uniform(0,len(colorset)))
             colorindex += 1
             colorindex = colorindex%len(colorset)
             colortype = colorset[colorindex]
             #linemark =  colortype+'-'+linetype
             linemark =  colortype+'-'
             plt.plot(sdsetlist, slowdownCDF,linemark,label=lablename)

             jobNum = (lineNum-1)/2
             print(str(jobNum) + " jobs have been read")
             print(lablename+" read done.")
             print('average stage slowdown: '+str(sum(slowdownList)/len(slowdownList)))
             print('average stage completion time: '+str((sum(stageList)/stageNum)*timeUnit))
             print('early stage completion time(90%): '+str((sum(earlyStageList)/len(earlyStageList))*timeUnit))
             print('early stage completion time(50%): '+str((sum(firstStageList)/len(firstStageList))*timeUnit))
             print('job completion time: '+str((sum(jobCompletionTimeList)/len(jobCompletionTimeList))*timeUnit))
             print('-------------------------------')
             #computing average slowdown time of different stages in each job
             sdFilename = 'slowdown-'+lablename
             sdout = open(source +'/'+sdFilename,'w')
             sdout.write('average stage slowdown\n') 
             for mdname in models:
                 stageslowdownbuf = []
                 for item in jobInfoList:
                     if item[1] != mdname:
                        continue
                     stageslowdownbuf.append(item[2])
                 #computing max stage numbers
                 maxstageNum = 0
                 for item in stageslowdownbuf:
                     if maxstageNum < len(item):
                        maxstageNum = len(item)
                 #computing average slowdown for each stage
                 averageSlowdown = []
                 for j in range(0,maxstageNum):
                     jobNum = 0
                     slowdownSum = 0
                     for item in stageslowdownbuf:
                         if j >= len(item):
                            continue
                         jobNum += 1
                         slowdownSum += item[j]
                     averageSlowdown.append(slowdownSum/jobNum)
                 #write to file
                 sdout.write(mdname+': '+str(averageSlowdown))
                 sdout.write('\n')
                 print('-----average stage slowdown for each model------------') 
                 print(mdname+': '+str(averageSlowdown))
             sdout.close()
             #computing average stage time of different stages in each job
             stFilename = 'stagetime-'+lablename
             stout = open(source +'/'+stFilename,'w')
             stout.write('average stage time\n') 
             for mdname in models:
                 stagetimebuf = []
                 for item in jobStageCtimeList:
                     if item[0] != mdname:
                        continue
                     stagetimebuf.append(item[1])
                 #computing max stage numbers
                 maxstageNum = 0
                 for item in stagetimebuf:
                     if maxstageNum < len(item):
                        maxstageNum = len(item)
                 #computing average slowdown for each stage
                 averagestagetime = []
                 for j in range(0,maxstageNum):
                     jobNum = 0
                     stagetimeSum = 0
                     for item in stagetimebuf:
                         if j >= len(item):
                            continue
                         jobNum += 1
                         stagetimeSum += item[j]
                     averagestagetime.append(stagetimeSum*timeUnit/jobNum)
                 #write to file
                 stout.write(mdname+': '+str(averagestagetime))
                 stout.write('\n')
                 print('-----average stage time for each model------------')
                 print(mdname+': '+str(averagestagetime))        
             stout.close()       
             #write result to files
             cdfFilename = 'cdf-'+lablename
             fout = open(source +'/'+cdfFilename,'w')
             fout.write('average stage slowdown: '+str(sum(slowdownList)/len(slowdownList))+'\n')
             fout.write('average stage completion time: '+str((sum(stageList)/len(stageList))*timeUnit)+'\n')
             fout.write('early stage completion time(90%): '+str((sum(earlyStageList)/len(earlyStageList))*timeUnit)+'\n')
             fout.write('early stage completion time(50%): '+str((sum(firstStageList)/len(firstStageList))*timeUnit)+'\n')
             fout.write('job completion time: '+str((sum(jobCompletionTimeList)/len(jobCompletionTimeList))*timeUnit)+'\n')
             fout.write('x: '+'\n')
             fout.write(str(sdsetlist)+'\n')
             fout.write('y: '+'\n')
             fout.write(str(slowdownCDF)+'\n')
             fout.close()
             break
plt.xlabel('Normalized Stage Slowdown')
plt.ylabel('CDF')
plt.legend(loc=4)
plt.title('Stage Slowdown CDF')
plt.show()
#plt.savefig('p2.png')
