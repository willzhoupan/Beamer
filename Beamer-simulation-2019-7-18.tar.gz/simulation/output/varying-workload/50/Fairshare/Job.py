import numpy as np
from config import dataUnit
from config import timeUnit
from config import hostNum
import config
import copy
from excutor import excutor
from Beamer import Beamer
import time
import os
import sys
class Job(object):
      def __init__(self,hNum,rlTime,**kwarg):
          self.hostNum = hNum
          self.releaseTime = rlTime
          self.prio = 0 #init the priority of the job
          self.workerList = []
          self.serverList = []
          self.stageList = []
          self.weightList = []#used for beamer algorithm
          self.tailStage = 0#used for beamer algorithm
          self.stageCtimes = []
          self.stageNow = 0
          self.iterNow = 0.0
          # gradient computing
          self.gaptime = 0.0
          self.flowsEmpty = np.zeros((hNum,hNum),dtype=float)
          self.flowsNow = np.zeros((hNum,hNum),dtype=float)
          self.flowNum = np.zeros((hNum,hNum),dtype=float)#used for fair share
          #kwarg = {'JobId':1,'modelName':'DenseNet','modelSize':'576-MB','workerHosts':'0-1-2',
          #         'serverHosts':'3-4','stageSizes':'200-200-400','ctime':2,'weight':1.0,'maxStage':3}
          for k,v in kwarg.items():
              setattr(self,k,v)
         
          workers = self.workerHosts.split('-')
          for item in workers:
              self.workerList.append(int(item))
 
          servers = self.serverHosts.split('-')
          for item in servers:
              self.serverList.append(int(item))
         
          stages = self.stageSizes.split('-')
          for item in stages:
              self.stageList.append(float(item))
          #Init all stage_weight equals to self.weight
          for i in range(0,len(stages)):
              temp = 0.0
              #computing w_jk
              for j in range(i,len(stages)):
                  temp += 1/self.stageList[j]
              temp = temp*self.weight 
              self.weightList.append(temp)
          self.stageGlobalPrio = np.zeros(len(self.stageList),dtype=int)
          self.tailStage = len(self.stageList) - 1

          fsize,funit = self.modelSize.split('-')
          self.flowSize = float(fsize)/(dataUnit*len(self.serverList))
          self.ctime = self.ctime/timeUnit
          #generate a coflow
          self.GeneratePushFlows()
          self.GeneratePullFlows() 

      def GeneratePushFlows(self):
          for worker in self.workerList:
              for server in self.serverList:
                  if worker<self.hostNum and server<self.hostNum:
                     #update worker->server data size
                     self.flowsNow[worker][server] += self.flowSize

      def GeneratePullFlows(self):
          for server in self.serverList:
              for worker in self.workerList:
                  if worker<self.hostNum and server<self.hostNum:
                     #update server->worker data size
                     self.flowsNow[server][worker] += self.flowSize
      '''
      def GenerateFlows(self):
          self.GeneratePushFlows()
          self.GeneratePullFlows()
      '''   
   
      def UpdateState(self,timeNow):
          if self.stageNow < 0:
                return 'completed!'          
          if (self.flowsNow == self.flowsEmpty).all():
             #all flows in this iteration have been transfered
             #update job stage and gaptime
             stage = -1
             if self.gaptime <= 0:
                self.iterNow += 1
                #Check job stage
                for i in range(0,len(self.stageList)):
                    if self.iterNow < self.stageList[i]:
                       stage = i
                       break
                if stage < 0 or stage > (self.maxStage-1): #job completed
                   self.stageNow = -1
                   self.stageCtimes.append(timeNow)
                   return 'completed!'
                else:
                   stageOld = self.stageNow
                   self.stageNow = stage
                   self.prio = self.stageGlobalPrio[self.stageNow]
                   self.gaptime = self.ctime
                   if self.gaptime <= 0:
                      self.GeneratePushFlows()
                      self.GeneratePullFlows()
                   if stageOld < stage:
                      self.stageCtimes.append(timeNow)
                      return 'stage_change!' 
                   return 'coflow_over'                     
                   #print('gaptime: '+str(self.gaptime))
             #Waiting for computing gradients
             else:
                self.gaptime -= 1
                self.prio = self.stageGlobalPrio[self.stageNow]
                #Gradients computing is finished
                if self.gaptime <= 0:
                   self.GeneratePushFlows()
                   self.GeneratePullFlows()
                   return 'gaptime_over'
                return 'gaptime_during'
          else:
              self.prio = self.stageGlobalPrio[self.stageNow]
              return 'coflow_tranfering'     
        
                   

if __name__ == "__main__":
      print('--------Fairshare started----------')
      filefolder = sys.argv[-1]
      print('file folder is: /'+filefolder)
      t_start = time.time()
      notArrivingJobList = []
      successfulJobList = []
      schedulelist = []
      fair_dcn = excutor()

      for item in config.notArrivingJobs:
          item[0] = item[0]/timeUnit
          #item[0] = 0
          if item[0] == 0:
             schedulelist.append(Job(hostNum,item[0],**item[1]))
          elif item[0] > 0:
             notArrivingJobList.append(item)
      notArrivingJobList.sort(key=lambda k:k[0],reverse = False)

      #stage changed flag
      stageChageFlag = False
      #off-line schedule
      for timeNow in range(0,100000000):
          #delete finished jobs from schedulelist
          runningJobNum = len(schedulelist)
          notArrivingJobNum = len(notArrivingJobList)
          if runningJobNum == 0 and notArrivingJobNum == 0:
             print('All job have completed!')
             break

          tempList = []
          if notArrivingJobNum > 0:
             for k in range(0,notArrivingJobNum):
                 item = notArrivingJobList[k]
                 if item[0] > timeNow:
                    break
                 schedulelist.append(Job(hostNum,item[0],**item[1]))
                 tempList.append(item)
             for item in tempList:
                 notArrivingJobList.remove(item)
                 print('new job arrivals!')

          completedJobList = []
          #update states of all jobs
          for i in range(0,runningJobNum):
              job = schedulelist[i]
              state = job.UpdateState(timeNow)
              if state == 'completed!':
                 completedJobList.append(job)
                 stageChageFlag = True
                 print('a job completed')
                 continue
              elif state == 'stage_change!':
                 stageChageFlag = True
          #delete completed jobs from schedulelist
          for cjob in completedJobList:
              successfulJobList.append(cjob)
              schedulelist.remove(cjob)
          if stageChageFlag == True:
             stageChageFlag = False
             '''
             print('-----------------------')
             print('1.densNetJob:')
             print(densNetJob.stageGlobalPrio)
             print('2.hotNetJob:')
             print(hotNetJob.stageGlobalPrio)
             print('3.nextNetJob:')
             print(nextNetJob.stageGlobalPrio)
             '''
          fair_dcn.TransferData(schedulelist)
      t_end = time.time()
      print('Total time is: '+ str(t_end-t_start))

      source = os.getcwd() + '/'+ filefolder+ '/'
      filename = 'output-FS'
      fout = open(source + filename,'w')
      totalStages = 0.0
      ctimeSum = 0.0
      earlyStageTimeSum = 0.0
      firstStageTimeSum = 0.0
      jobCtimeSum = 0.0
      num50 = 0.0
      num90 = 0.0
      for job in successfulJobList:
          totalStages += len(job.stageCtimes)
          ctimeSum += sum(job.stageCtimes)*timeUnit
          if len(job.stageCtimes) >= 4:
             earlyStageTimeSum += job.stageCtimes[3]*timeUnit
             num90 += 1
          if len(job.stageCtimes) >= 3:
             firstStageTimeSum += job.stageCtimes[2]*timeUnit
             num50 += 1
          jobCtimeSum += job.stageCtimes[-1]*timeUnit
          #print('------------')
          #print(job.modelName)
          fout.write(job.modelName+','+str(job.JobId)+','+str((job.releaseTime)*timeUnit)+'\n')
          #print(job.stageCtimes)
          fout.write(str(job.stageCtimes))
          fout.write('\n')
      fout.close()
      print('Average stage time:')
      print(str(ctimeSum/totalStages)+' s')
      if num90 > 0:
         print('Early stage time(90%):')
         print(str(earlyStageTimeSum/num90)+ ' s')
      if num50 > 0:
         print('Early stage time(50%):')
         print(str(firstStageTimeSum/num50)+ ' s')
      print('Job completion time:')
      print(str(jobCtimeSum/len(successfulJobList))+ ' s')
   


