import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import numpy as np
import scipy.optimize
import random
import os
import re
import math
import json

loadpercent = 0.1
nodeamount = 40
#-------------------create file flow object--------------------------------------
source = os.getcwd() + '/'
filename = 'joblist.py'
hostNum = 10
jobNum = 40
stageNum = 6
coflowNum = 10
maxWorkerNum = 6
loadpercent = 100
computing_time = 0.0
jobweight = 1.0

fout = open(source + filename,'w')

#-------------------Model size MB and Model name--------------------------------
modelSize = np.array(['10.0-MB','20.0-MB', '30.0-MB', '100.0-MB', '160.0-MB','230.0-MB','250.0-MB','580.0-MB'])
modelName = np.array(['ResNext-110','RNN-LSTM-Dropout','DenseNet121','Inception_V3', 'DeepSpeech2','ResNet152','AlexNet','VGG19'])
#-------------------Job arrival interval CDF--------------------------------
intertime = np.array([1, 1, 2, 2, 6, 6, 7, 7, 8, 8, 10,20,30,40,80,100,200,300,400,800,1000,2000,7000])
interpro = np.array([0.26, 0.3, 0.3, 0.32, 0.32, 0.35, 0.35, 0.4, 0.4, 0.45, 0.45,0.64,0.67,0.7,0.8,0.83,0.9,0.95,0.96,0.98,0.99,0.995,1])
#-------------------job arrival interval CDF when considering loadpercent---------
for i in range(0,len(intertime)):
    intertime[i] = intertime[i]/loadpercent
#-------------------generate trace ---------------------------------------------
#kwarg = {'JobId':1,'modelName':'DenseNet','modelSize':'576-MB','workerHosts':'0-1-2',
#         'serverHosts':'3-4','stageSizes':'200-200-400','ctime':2,'weight':1.0,'maxStage':3}
jobstarttime = 0
jobtrace = []
for i in range(0,jobNum):
    jobdict = {}
    #job id 
    jobdict['JobId'] = i
    #generate modelSize
    modelIndex = random.randint(4,len(modelSize)-1)
    modelSizeStr = modelSize[modelIndex]
    modelNameStr = modelName[modelIndex]
    jobdict['modelName'] = modelNameStr
    jobdict['modelSize'] = modelSizeStr

    #model name and model size
    stageSizeStr = ''
    for stage in range(0,stageNum):
        if stage == stageNum-1:
           stageSizeStr += str(coflowNum*(3*2**stage)) + '-'
        else:
           stageSizeStr += str(coflowNum*(2**stage)) + '-'
    stageSizeStr = stageSizeStr[:-1]
    jobdict['stageSizes'] = stageSizeStr
    jobdict['maxStage'] = random.randint(1,stageNum)
    #worker number and server number
    workerNum = random.randint(1,maxWorkerNum)
    serverNum = workerNum
    workerHostsStr = ''
    serverHostsStr = ''
    for node in range(0,workerNum):
        workerHostsStr += str((i+node)%hostNum)+'-'
        serverHostsStr += str((i+node+workerNum)%hostNum)+'-'
    workerHostsStr = workerHostsStr[:-1]
    serverHostsStr = serverHostsStr[:-1]
    jobdict['workerHosts'] = workerHostsStr
    jobdict['serverHosts'] = serverHostsStr
    jobdict['ctime'] = computing_time
    jobdict['weight'] = jobweight
    #-----------------------write data to .py--------------------------------------
    jobtrace.append((jobstarttime,jobdict))
    print('--------------------')
    print('starttime: '+str(jobstarttime))
    print(jobdict)
    #generate start time of next job
    randomProbility = random.uniform(0,0.9)
    for j in range(0,len(interpro)):
        if randomProbility < interpro[j] and j>0:
           xset = np.array([intertime[j-1],intertime[j]])
           yset = np.array([interpro[j-1],interpro[j]])
           if xset[0]!=xset[1]:
              a = (yset[0]-yset[1])/(xset[0]-xset[1])
              b = -(yset[0]-yset[1])*xset[1]/(xset[0]-xset[1])+yset[1]
              interval = (randomProbility - b)/a
           else:
              interval = xset[0]
           break
        elif j == 0:
           interval = 0 

    jobstarttime += interval    
js = json.dumps(jobtrace)
fout.write(js)
fout.close()
print('completed!')

#plt.savefig('p2.png')
