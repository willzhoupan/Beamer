# for fair share
import numpy as np
from config import hostNum
import copy
class excutor(object):
      def __init__(self,**kwarg):
          self.hostNum = hostNum
          #//Init port's capacity to 1, 
          #first hNum is egress ports
          #last hNum is ingress ports //    
          self.portsCapcity = np.ones(2*hostNum,dtype=float)
          
          #kwarg is used for extending
          for k,v in kwarg.items():
              setattr(self,k,v)      
             
      def TransferData(self,jobList):
          #Init the ports' capacity to 1
          self.portsCapcity = np.ones(2*hostNum,dtype=float)

          # Delete completed jobs from jobList
          completedJobList = []
          for i in range(0,len(jobList)):
              job = jobList[i]
              # find completed jobs from jobList
              if job.stageNow < 0:
                 completedJobList.append(job)
                 continue
          for cjob in completedJobList:
              jobList.remove(cjob)

          #transfer jobs using Fair share method
          self.TransferJobFairShare(jobList)
      
      def TransferJobFairShare(self,jobList):
          zeroMatrix = np.zeros((self.hostNum,self.hostNum),dtype=float)
          # find busy jobs from jobList
          busyJobList = []
          for i in range(0,len(jobList)):
              job = jobList[i]
              # find busy jobs from jobList
              if not (job.flowsNow == zeroMatrix).all():
                 busyJobList.append(job) 
        
          #computing flow number of each pipeline
          pipeMatrix = np.zeros((self.hostNum,self.hostNum),dtype=float)
          for job in busyJobList:
              job.flowNum = np.zeros((self.hostNum,self.hostNum),dtype=float)
              for worker in job.workerList:
                  for server in job.serverList:
                      #have data to transfer
                      if job.flowsNow[worker][server] > 0:
                         pipeMatrix[worker][server] += 1#push direction
                         job.flowNum[worker][server] += 1
                      #have data to transfer
                      if job.flowsNow[server][worker] > 0:
                         pipeMatrix[server][worker] += 1#pull  direction
                         job.flowNum[server][worker] += 1

          self.WorkConservingTransfer(busyJobList,pipeMatrix)
 
      #worker conserving transfer
      def WorkConservingTransfer(self,busyJobList,pipeMatrix):
          zeroMatrix = np.zeros((self.hostNum,self.hostNum),dtype=float)
          while(True): 
            if len(busyJobList) == 0:
               break          
            #computing egress per-flow bandwidth
            bwSrc = np.zeros((self.hostNum,self.hostNum),dtype=float)
            for i in range(0,self.hostNum):
                src = pipeMatrix[i]
                flowNum = src.sum()
                dtemp = np.nonzero(src)
                dsts = dtemp[0]
                if flowNum > 0:
                   egressBw = self.portsCapcity[i]/flowNum#capacity/flow_number
                   for j in dsts:
                       bwSrc[i][j] = egressBw#
            #computing ingress per-flow bandwidth
            bwDst = np.zeros((self.hostNum,self.hostNum),dtype=float)
            for j in range(0,self.hostNum):
                dst = pipeMatrix[:,j]
                flowNum = dst.sum()
                stemp = np.nonzero(dst)
                srcs = stemp[0]
                if flowNum > 0:
                   ingressBw = self.portsCapcity[j+self.hostNum]/flowNum
                   for i in srcs:
                       bwDst[i][j] = ingressBw
            #computing point to point per-flow bandwidth
            bw = np.zeros((self.hostNum,self.hostNum),dtype=float)
            for i in range(0,self.hostNum):
                for j in range(0,self.hostNum):
                    bw[i][j] = min(bwSrc[i][j],bwDst[i][j])
                    if bw[i][j] == 0:
                       bw[i][j] = float('inf')
            
            
            row,col = divmod(np.argmin(bw),np.shape(bw)[1])
            #No bandwidth left
            if bw[row][col] == float('inf'):
               break
            #transfer flows from row_th host to col_th host
            transferedJob = []
            for job in busyJobList:
                flowNum = job.flowNum[row][col]
                #there is not any flow for the job to transfer from row_th host to col_th host
                if flowNum <= 0:
                   continue
                #transfer flows  
                job.flowsNow[row][col] -= (bw[row][col]*flowNum)
                if job.flowsNow[row][col] <= 1e-10:#float error
                   job.flowsNow[row][col] = 0
                #update flow numbers
                #flow number in pipeline
                pipeMatrix[row][col] = max(pipeMatrix[row][col]-flowNum,0)
                #flow number in pipeline of the job
                job.flowNum[row][col] = 0
                #update port capacity
                self.portsCapcity[row] = max(self.portsCapcity[row]-bw[row][col]*flowNum,0) #egress port
                if self.portsCapcity[row] <= 1e-10:#float error
                   self.portsCapcity[row] = 0
                self.portsCapcity[col+self.hostNum] = max(self.portsCapcity[col+self.hostNum]-bw[row][col]*flowNum,0) #ingress port
                if self.portsCapcity[col+self.hostNum] <= 1e-10:#float error
                   self.portsCapcity[col+self.hostNum] = 0
                #delete transfered busy job
                if (job.flowNum == zeroMatrix).all():
                   transferedJob.append(job)
            for job in transferedJob:
                busyJobList.remove(job)              
            '''
            print('transReq:')
            print(transReq)
            input('input:')
            '''
                
            


