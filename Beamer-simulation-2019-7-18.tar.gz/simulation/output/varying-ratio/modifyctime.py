import scipy.optimize
import random
import os
import re
import math
import json
#-------------------copy notArrivingJobs from /BeamerOnline/config.py---
import config
hostNum = config.hostNum #Host number
bandwidth = config.bandwidth#Gbps
dataUnit = config.dataUnit #MB
timeUnit = config.timeUnit #Seconds
notArrivingJobs = config.notArrivingJobs
ratio = 100 #CommuicationToComputing

#-------------------generate trace ---------------------------------------------
#kwarg = {'JobId':1,'modelName':'DenseNet','modelSize':'576-MB','workerHosts':'0-1-2',
#         'serverHosts':'3-4','stageSizes':'200-200-400','ctime':2,'weight':1.0,'maxStage':3}
jobtrace = []
for item in notArrivingJobs:
    jobstarttime = item[0]
    jobdict = item[1]
    #generate modelSize
    modelSizeStr = jobdict['modelSize']
    templist = modelSizeStr.split('-')
    modelSize = float(templist[0])
    workerStr = jobdict['workerHosts']
    serverStr = jobdict['serverHosts']
    workerNum = float(len(workerStr.split('-')))
    serverNum = float(len(serverStr.split('-')))
    #computing computing time for a given job
    if workerNum >= serverNum:
       perServerDataSize = (modelSize/serverNum)*workerNum
       communicationTime = perServerDataSize/(bandwidth*125.0)
    else:
       perWorkerDataSize = modelSize
       communicationTime = perWorkerDataSize/(bandwidth*125.0)
    computingTime = communicationTime/ratio
    jobdict['ctime'] = computingTime
    

    jobtrace.append((jobstarttime,jobdict))
#-----------------------write data to .py--------------------------------------
source = os.getcwd() + '/'
filename = 'joblist-modified-ctime.py'    
js = json.dumps(jobtrace)
fout = open(source + filename,'w')
fout.write(js)
fout.close()
print('completed!')

#plt.savefig('p2.png')
