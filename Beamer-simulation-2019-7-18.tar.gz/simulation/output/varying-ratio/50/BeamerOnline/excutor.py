import numpy as np
from config import hostNum
import copy
class excutor(object):
      def __init__(self,**kwarg):
          self.hostNum = hostNum
          #//Init port's capacity to 1, 
          #first hNum is egress ports
          #last hNum is ingress ports //    
          self.portsCapcity = np.ones(2*hostNum,dtype=float)
          
          #kwarg is used for extending
          for k,v in kwarg.items():
              setattr(self,k,v)      
             
      def TransferData(self,jobList):
          #Init the ports' capacity to 1
          self.portsCapcity = np.ones(2*hostNum,dtype=float)
          sortList = []
          #sortList:[(nextNetJob,nextNetJob.prio),(densNetJob,densNetJob.prio),...,]
          #job sort from high priority (low value) to low priority (high value)
          for job in jobList:
              sortList.append((job,job.prio))
          sortList.sort(key=lambda k:k[1],reverse = False)
          for i in range(0,len(sortList)):
              jobtemp = sortList[i][0]
              self.TransferJob(jobtemp)
      
      def TransferJob(self,jobtemp):
          transReq = copy.deepcopy(jobtemp.flowsNow)
          zeroMatrix = np.zeros((self.hostNum,self.hostNum),dtype=float)
          while(True):
            if (transReq == zeroMatrix).all():
               break

            #computing egress bandwidth
            bwSrc = np.zeros((self.hostNum,self.hostNum),dtype=float)
            for i in range(0,self.hostNum):
                src = transReq[i]
                dtemp = np.nonzero(src)
                dsts = dtemp[0]
                if len(dsts) > 0:
                   egressBw = self.portsCapcity[i]/len(dsts)
                   for j in dsts:
                       bwSrc[i][j] = egressBw
            #computing ingress bandwidth
            bwDst = np.zeros((self.hostNum,self.hostNum),dtype=float)
            for j in range(0,self.hostNum):
                dst = transReq[:,j]
                stemp = np.nonzero(dst)
                srcs = stemp[0]
                if len(srcs) > 0:
                   ingressBw = self.portsCapcity[j+self.hostNum]/len(srcs)
                   for i in srcs:
                       bwDst[i][j] = ingressBw
            #computing point to point bandwidth
            bw = np.zeros((self.hostNum,self.hostNum),dtype=float)
            for i in range(0,self.hostNum):
                for j in range(0,self.hostNum):
                    bw[i][j] = min(bwSrc[i][j],bwDst[i][j])
                    if bw[i][j] == 0:
                       bw[i][j] = float('inf')
            
            
            row,col = divmod(np.argmin(bw),np.shape(bw)[1])
            #No bandwidth left
            if bw[row][col] == float('inf'):
               break
            #transfer a flow
            transReq[row][col] = 0.0
            jobtemp.flowsNow[row][col] = jobtemp.flowsNow[row][col]-bw[row][col]
            if jobtemp.flowsNow[row][col] <= 1e-10:#float error
               jobtemp.flowsNow[row][col] = 0
            #computing left bandwidth
            
            self.portsCapcity[row] = max(self.portsCapcity[row]-bw[row][col],0) #egress port
            if self.portsCapcity[row] <= 1e-10:#float error
               self.portsCapcity[row] = 0
            self.portsCapcity[col+self.hostNum] = max(self.portsCapcity[col+self.hostNum]-bw[row][col],0) #ingress port
            if self.portsCapcity[col+self.hostNum] <= 1e-10:#float error
               self.portsCapcity[col+self.hostNum] = 0            
            '''
            print('transReq:')
            print(transReq)
            input('input:')
            '''
                
            


