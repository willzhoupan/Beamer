#!/bin/sh
echo 'hello ratio'
#0.1
python3 ./0.1/BeamerOnline/Job.py 0.1
python3 ./0.1/Fairshare/Job.py 0.1
python3 ./0.1/FIFO-LM/Job.py 0.1
python3 ./0.1/Sincrona/Job.py 0.1
#0.5
python3 ./0.5/BeamerOnline/Job.py 0.5
python3 ./0.5/Fairshare/Job.py 0.5
python3 ./0.5/FIFO-LM/Job.py 0.5
python3 ./0.5/Sincrona/Job.py 0.5
#1
python3 ./1/BeamerOnline/Job.py 1
python3 ./1/Fairshare/Job.py 1
python3 ./1/FIFO-LM/Job.py 1
python3 ./1/Sincrona/Job.py 1
#1.5
python3 ./1.5/BeamerOnline/Job.py 1.5
python3 ./1.5/Fairshare/Job.py 1.5
python3 ./1.5/FIFO-LM/Job.py 1.5
python3 ./1.5/Sincrona/Job.py 1.5
#2
python3 ./2/BeamerOnline/Job.py 2
python3 ./2/Fairshare/Job.py 2
python3 ./2/FIFO-LM/Job.py 2
python3 ./2/Sincrona/Job.py 2
#5
python3 ./5/BeamerOnline/Job.py 5
python3 ./5/Fairshare/Job.py 5
python3 ./5/FIFO-LM/Job.py 5
python3 ./5/Sincrona/Job.py 5
#10
python3 ./10/BeamerOnline/Job.py 10
python3 ./10/Fairshare/Job.py 10
python3 ./10/FIFO-LM/Job.py 10
python3 ./10/Sincrona/Job.py 10
#50
python3 ./50/BeamerOnline/Job.py 50
python3 ./50/Fairshare/Job.py 50
python3 ./50/FIFO-LM/Job.py 50
python3 ./50/Sincrona/Job.py 50
#100
python3 ./100/BeamerOnline/Job.py 100
python3 ./100/Fairshare/Job.py 100
python3 ./100/FIFO-LM/Job.py 100
python3 ./100/Sincrona/Job.py 100

