#!/bin/sh
echo 'hello period'

#1
python3 ./1/BeamerOnline/Job.py 1
#5
python3 ./5/BeamerOnline/Job.py 5
#10
python3 ./10/BeamerOnline/Job.py 10
#20
python3 ./20/BeamerOnline/Job.py 20
#40
python3 ./40/BeamerOnline/Job.py 40
#60
python3 ./60/BeamerOnline/Job.py 60
#80
python3 ./80/BeamerOnline/Job.py 80
#100
python3 ./100/BeamerOnline/Job.py 100

