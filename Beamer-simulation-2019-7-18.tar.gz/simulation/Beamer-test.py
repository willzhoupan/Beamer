import unittest
import numpy as np
import random
import matplotlib.pyplot as plt
import os

we1 = 8.0
wl1 = 1.0
e1 = 50
l1 = 100
p1 = 4.0
wks1 = np.zeros(l1+1)
wks1[e1] = we1
wks1[l1] = wl1

we2 = 12.0
wl2 = 1.0
e2 = 100
l2 = 150
p2 = 5.0
wks2 = np.zeros(l2+1)
wks2[e2] = we2
wks2[l2] = wl2

def newwk(wk,*args):
    #Sprint args
    wej = float(args[0][0])
    wlj = float(args[0][1])
    ej = float(args[0][2])
    lj = float(args[0][3])
    pj = args[0][4]
    deta = float(1/(lj*lj*lj))
    wks = np.zeros(int(lj)+1)
    Ajk = np.zeros(int(lj)+2)
    Ajk[0] = 0 #not used
    Ajk[1] = 0 # first item
    Ajk[int(lj)+1] = 0
    # computing Ajk
    for k in range(2,int(lj)+1):
        #Ajk[k] = wjk/k+wjk+1/(k+1)+...+wjl/l
        for n in range(k,int(lj)+1):
            Ajk[k] = Ajk[k] + wk[n]/n
        Ajk[k] = (k-1)*Ajk[k]

    # computing wjk = wjk + (Aj_k+1)-Ajk
    for k in range(1,int(lj)+1):
        wks[k] = wk[k] + Ajk[k+1] - Ajk[k] + (lj-2*k+3)*deta
    return wks

if __name__ == "__main__":
   
   new_wks1 = newwk(wks1,[we1,wl1,e1,l1,p1])
   new_wks2 = newwk(wks2,[we2,wl2,e2,l2,p2])
   copy_wks1 = new_wks1[-len(new_wks1)+1:]
   copy_wks2 = new_wks2[-len(new_wks2)+1:]
   # schedule from last to first
   index = 0 
   for i in range(1,l1+l2+1):
       index += 1
       min_wks1 = copy_wks1.min()
       min_wks2 = copy_wks2.min()
       deta_wks1 = min_wks1/p1
       deta_wks2 = min_wks2/p2
      # print "job1 deta: "+str(deta_wks1)
      # print "job2 deta: "+str(deta_wks2)
       if deta_wks1 < deta_wks2 :
          deta = deta_wks1
          print str(index)+" job1 "+ str(len(copy_wks1))+"th iteration"
       else:
          deta = deta_wks2
          print str(index)+" job2 "+ str(len(copy_wks2))+"th iteration"

       for k in range(0,len(copy_wks1)):
           copy_wks1[k] = copy_wks1[k] - deta*p1
           
       for k in range(0,len(copy_wks2)):
           copy_wks2[k] = copy_wks2[k] - deta*p2

       if len(copy_wks1) >= 2:
          if copy_wks1[-1]==0:
             copy_wks1 = copy_wks1[:-1]
       else:
          copy_wks1[0] = 100
      
       if len(copy_wks2) >= 2:
          if copy_wks2[-1]==0:
             copy_wks2 = copy_wks2[:-1]
       else:
          copy_wks2[0] = 100       
      
   '''
   plt.plot(Bandwidth,BCTminbuf,linestyle='-',color='g',marker='s',label='BCTmin')
   plt.plot(Bandwidth,real_data,linestyle='-',color='b',marker='p',label='Measured')
   plt.plot(Bandwidth,BCTcomputebuf,linestyle='-',color='black',marker='d',label='Predicted')
   plt.plot(Bandwidth,BCTmaxbuf,linestyle='-',color='r',marker='o',label='BCTmax')
   
   plt.xlabel('bandwidth')
   plt.ylabel('Batch time')
   plt.legend(loc=1)
   plt.show()
   print("plot done.")
   '''

