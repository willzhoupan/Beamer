#!/bin/sh
echo 'hello'
python3 ./BeamerOnline/Job.py
python3 ./Fairshare/Job.py
python3 ./FIFO-LM/Job.py
python3 ./Sincrona/Job.py
